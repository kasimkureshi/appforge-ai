# AppForge AI

Describe a website in plain English → get a multi-page site → preview it live → change it with follow-up
instructions → download the source as a ZIP.

Built with **React + TypeScript + Tailwind CSS** (web app) and a small **Node server** that keeps the AI key secret.

## Run it (needs Node 20.19+ and internet for the first install)

```bash
npm install
npm run dev          # web app: http://localhost:5173  (API: http://localhost:8787)
npm test             # core tests
npm run build        # production build into dist/
npm start            # server only; serves dist/ if built
```

## Publish for free on Cloudflare Pages (phone-friendly)

The build runs in Cloudflare's cloud, so you never need Node on your own device.

1. Make a free GitHub repository and upload `appforge-ai.zip` (just this one file) to it.
2. In Cloudflare: Workers & Pages -> Create -> Pages -> Connect to Git -> choose that repository.
3. Settings:
   - Framework preset: None
   - Build command: `(unzip -oq appforge-ai.zip || python3 -m zipfile -e appforge-ai.zip .) && cd appforge-ai && npm install && npm run build`
   - Build output directory: `appforge-ai/dist`
   - Environment variable: `NODE_VERSION` = `22`
4. Save and Deploy. You get a free `https://your-name.pages.dev` address.
5. Optional, for real AI: Settings -> Variables and Secrets -> add `ANTHROPIC_API_KEY` as a Secret, then redeploy.

`npm run build` makes the web app (Vite) and `dist/_worker.js` (the API for Cloudflare, from `worker/index.ts`).

## Demo mode vs AI mode

- **No API key** → demo mode. A built-in generator makes sites from keywords. Works offline.
- **With a key** → copy `.env.example` to `.env` and set `ANTHROPIC_API_KEY=...`. The key stays on the server and is never sent to the browser.

## Layout

| Folder | What it does |
| --- | --- |
| `src/` | React + Tailwind interface (mobile-first) |
| `server/` | `api.ts` (the API, shared), `app.ts` (local Node server), AI call, rate limiting |
| `worker/` | Cloudflare Pages entry point |
| `shared/` | Code used by both: demo generator, validation, preview builder, ZIP writer |
| `tests/` | Automated tests |

## Plans (Step 1 status)

- Free plan with an ad placeholder: built (`AdBanner.tsx`).
- Pro ₹299/month: pricing UI built; **real payments are not connected yet**.
- Premium features and custom services: listed in the UI; the quote button needs `VITE_CONTACT_EMAIL`.
