// Starts the website (Vite, port 5173) and the API server (port 8787) together.
import { spawn } from 'node:child_process'

const isWindows = process.platform === 'win32'
const npx = isWindows ? 'npx.cmd' : 'npx'

function run(label, args) {
  const child = spawn(npx, args, { stdio: 'inherit', shell: isWindows })
  child.on('exit', (code) => {
    console.log(`[${label}] stopped (code ${code})`)
    process.exit(code ?? 0)
  })
  return child
}

const children = [run('web', ['vite']), run('api', ['tsx', 'server/index.ts'])]

for (const signal of ['SIGINT', 'SIGTERM']) {
  process.on(signal, () => {
    for (const child of children) child.kill()
    process.exit(0)
  })
}
