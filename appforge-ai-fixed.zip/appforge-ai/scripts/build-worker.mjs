// Bundles worker/index.ts into dist/_worker.js, the file Cloudflare Pages runs for /api requests.
import { build } from 'esbuild'

await build({
  entryPoints: ['worker/index.ts'],
  bundle: true,
  format: 'esm',
  platform: 'browser',
  target: 'es2022',
  outfile: 'dist/_worker.js',
  logLevel: 'info',
})
