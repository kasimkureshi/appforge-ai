import { createServer, type IncomingMessage, type Server, type ServerResponse } from 'node:http'
import { existsSync, readFileSync, statSync } from 'node:fs'
import { extname, join, normalize, resolve, sep } from 'node:path'
import type { ErrorResponse } from '../shared/types'
import type { FetchLike } from './ai'
import { createApiHandler, jsonResponse, MAX_BODY_BYTES } from './api'

/** Local Node server: serves the built web app and passes /api requests to the shared API handler. */

const MIME: Record<string, string> = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
  '.txt': 'text/plain; charset=utf-8',
}

export interface AppOptions {
  env?: NodeJS.ProcessEnv
  /** Replace fetch in tests so no real AI calls are made. */
  fetchImpl?: FetchLike
  /** Folder with the built website (npm run build). Served when it exists. */
  distDir?: string
}

function sendJson(res: ServerResponse, status: number, body: unknown): void {
  res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' })
  res.end(JSON.stringify(body))
}

/** Reads the request body, giving up (null) if it is bigger than the limit. */
async function readBody(req: IncomingMessage): Promise<Buffer | null> {
  const chunks: Buffer[] = []
  let size = 0
  for await (const chunk of req) {
    size += (chunk as Buffer).length
    if (size > MAX_BODY_BYTES) return null
    chunks.push(chunk as Buffer)
  }
  return Buffer.concat(chunks)
}

export function createApp(options: AppOptions = {}): Server {
  const env = options.env ?? process.env
  const distDir = resolve(options.distDir ?? 'dist')
  const handleApi = createApiHandler({ getEnv: () => env, fetchImpl: options.fetchImpl })

  async function nodeToApi(req: IncomingMessage, res: ServerResponse): Promise<void> {
    const headers = new Headers()
    for (const [key, value] of Object.entries(req.headers)) {
      if (typeof value === 'string') headers.set(key, value)
    }
    const hasBody = req.method !== 'GET' && req.method !== 'HEAD'
    const body = hasBody ? await readBody(req) : undefined
    let response: Response
    if (body === null) {
      response = jsonResponse(413, { error: 'The request is too large.' } satisfies ErrorResponse)
    } else {
      const request = new Request(new URL(req.url ?? '/', 'http://localhost'), {
        method: req.method,
        headers,
        body: hasBody ? new Uint8Array(body ?? Buffer.alloc(0)) : undefined,
      })
      response = await handleApi(request, req.socket.remoteAddress ?? 'unknown')
    }
    const out: Record<string, string> = {}
    response.headers.forEach((value, key) => (out[key] = value))
    res.writeHead(response.status, out)
    res.end(Buffer.from(await response.arrayBuffer()))
  }

  function serveStatic(res: ServerResponse, path: string): void {
    if (!existsSync(distDir)) {
      return sendJson(res, 404, {
        error: 'The web app is not built yet. Use "npm run dev" while developing, or run "npm run build" first.',
      } satisfies ErrorResponse)
    }
    let relative = path
    try {
      relative = decodeURIComponent(path)
    } catch {
      return sendJson(res, 400, { error: 'Bad URL.' } satisfies ErrorResponse)
    }
    let file = normalize(join(distDir, relative))
    if (file !== distDir && !file.startsWith(distDir + sep)) {
      return sendJson(res, 403, { error: 'Forbidden.' } satisfies ErrorResponse)
    }
    if (!existsSync(file) || statSync(file).isDirectory()) file = join(distDir, 'index.html') // single-page app fallback
    res.writeHead(200, { 'content-type': MIME[extname(file)] ?? 'application/octet-stream' })
    res.end(readFileSync(file))
  }

  return createServer((req, res) => {
    // Basic security headers for every response.
    res.setHeader('x-content-type-options', 'nosniff')
    res.setHeader('x-frame-options', 'DENY')
    res.setHeader('referrer-policy', 'no-referrer')

    const path = new URL(req.url ?? '/', 'http://localhost').pathname
    if (path.startsWith('/api/')) {
      nodeToApi(req, res).catch((error: unknown) => {
        console.error('[server error]', error instanceof Error ? error.message : error)
        if (!res.headersSent) sendJson(res, 500, { error: 'Something went wrong.' } satisfies ErrorResponse)
      })
      return
    }
    if (req.method !== 'GET' && req.method !== 'HEAD') {
      return sendJson(res, 405, { error: 'Method not allowed.' } satisfies ErrorResponse)
    }
    serveStatic(res, path)
  })
}
