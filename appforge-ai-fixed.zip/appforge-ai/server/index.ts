import { createApp } from './app'
import { getAiConfig } from './ai'
import { loadEnvFile } from './env'

loadEnvFile('.env')

const port = Number(process.env.PORT ?? 8787)
const ai = getAiConfig(process.env)

createApp().listen(port, () => {
  console.log(`AppForge AI server running on http://localhost:${port}`)
  console.log(
    ai
      ? `AI mode ON (model: ${ai.model}). The API key stays on this server.`
      : 'Demo mode (no ANTHROPIC_API_KEY found). Add one to .env to turn on real AI.',
  )
})
