/**
 * A very small in-memory rate limiter: each visitor (by IP address) may make
 * `max` requests per `windowMs`. It stops one person from running up your AI bill.
 * (For many servers, use a shared store like Redis instead.)
 */
export function createRateLimiter(max: number, windowMs: number) {
  const hits = new Map<string, number[]>()

  return function allow(key: string, now = Date.now()): boolean {
    const recent = (hits.get(key) ?? []).filter((t) => now - t < windowMs)
    if (recent.length >= max) {
      hits.set(key, recent)
      return false
    }
    recent.push(now)
    hits.set(key, recent)
    // Keep memory small: forget visitors that have been quiet for a while.
    if (hits.size > 5000) {
      for (const [k, times] of hits) {
        if (times.every((t) => now - t >= windowMs)) hits.delete(k)
      }
    }
    return true
  }
}
