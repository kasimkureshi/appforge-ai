import { applyDemoEdit, generateDemoSite } from '../shared/demo'
import { LIMITS, type EngineMode, type ErrorResponse, type SiteResponse, type StatusResponse } from '../shared/types'
import { validateSite } from '../shared/validate'
import { editWithAi, generateWithAi, getAiConfig, type FetchLike } from './ai'
import { createRateLimiter } from './rateLimit'

/**
 * The whole API as ONE function: Request in, Response out (web standards).
 * The same code runs in two places:
 *   - server/app.ts   (Node, for local use)
 *   - worker/index.ts (Cloudflare Pages, for free online hosting)
 */

export type Env = Record<string, string | undefined>

export const MAX_BODY_BYTES = 1_500_000

export class HttpError extends Error {
  constructor(
    public status: number,
    message: string,
  ) {
    super(message)
  }
}

export interface ApiOptions {
  /** Returns the settings (API key etc.). A function, because on Cloudflare they arrive with each request. */
  getEnv: () => Env
  /** Replace fetch in tests so no real AI calls are made. */
  fetchImpl?: FetchLike
}

export function jsonResponse(status: number, body: unknown): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: {
      'content-type': 'application/json; charset=utf-8',
      'cache-control': 'no-store',
      'x-content-type-options': 'nosniff',
      'x-frame-options': 'DENY',
      'referrer-policy': 'no-referrer',
    },
  })
}

async function readJson(req: Request): Promise<Record<string, unknown>> {
  const declared = Number(req.headers.get('content-length') ?? 0)
  if (declared > MAX_BODY_BYTES) throw new HttpError(413, 'The request is too large.')
  const text = await req.text()
  if (new TextEncoder().encode(text).length > MAX_BODY_BYTES) throw new HttpError(413, 'The request is too large.')
  try {
    const parsed: unknown = JSON.parse(text || '{}')
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) throw new Error()
    return parsed as Record<string, unknown>
  } catch {
    throw new HttpError(400, 'The request body must be valid JSON.')
  }
}

function cleanText(value: unknown, min: number, max: number, label: string): string {
  if (typeof value !== 'string') throw new HttpError(400, `${label} is required.`)
  const text = value.trim()
  if (text.length < min) throw new HttpError(400, `${label} is too short.`)
  if (text.length > max) throw new HttpError(400, `${label} is too long (max ${max} characters).`)
  return text
}

type Limiter = (key: string) => boolean

export function createApiHandler(options: ApiOptions): (req: Request, ip: string) => Promise<Response> {
  const fetchImpl: FetchLike = options.fetchImpl ?? ((url, init) => fetch(url, init))
  let allowAi: Limiter | undefined
  let allowDemo: Limiter | undefined

  async function route(req: Request, ip: string): Promise<Response> {
    const env = options.getEnv()
    // Per-visitor limits: AI calls cost money, so they are limited more strictly.
    // (In-memory: on Cloudflare each server instance keeps its own counts.)
    allowAi ??= createRateLimiter(Number(env.AI_RATE_LIMIT ?? 20), 10 * 60_000)
    allowDemo ??= createRateLimiter(120, 10 * 60_000)

    const aiConfig = getAiConfig(env)
    const path = new URL(req.url).pathname

    if (req.method === 'GET' && path === '/api/status') {
      const body: StatusResponse = aiConfig
        ? { mode: 'ai', aiConfigured: true, model: aiConfig.model }
        : { mode: 'demo', aiConfigured: false }
      return jsonResponse(200, body)
    }

    if (req.method === 'POST' && (path === '/api/generate' || path === '/api/edit')) {
      const body = await readJson(req)
      const useAi = Boolean(aiConfig) && body.forceDemo !== true
      if (!(useAi ? allowAi : allowDemo)(ip)) {
        throw new HttpError(429, 'Too many requests. Please wait a few minutes and try again.')
      }
      const mode: EngineMode = useAi ? 'ai' : 'demo'

      if (path === '/api/generate') {
        const prompt = cleanText(body.prompt, LIMITS.minPromptChars, LIMITS.maxPromptChars, 'Your description')
        const result =
          useAi && aiConfig ? await generateWithAi(prompt, aiConfig, fetchImpl) : generateDemoSite(prompt)
        const response: SiteResponse = { site: result.site, mode, summary: result.summary }
        return jsonResponse(200, response)
      }

      const instruction = cleanText(body.instruction, 2, LIMITS.maxInstructionChars, 'Your instruction')
      let site
      try {
        site = validateSite(body.site)
      } catch (error) {
        throw new HttpError(400, error instanceof Error ? error.message : 'Invalid website data.')
      }
      const result =
        useAi && aiConfig ? await editWithAi(site, instruction, aiConfig, fetchImpl) : applyDemoEdit(site, instruction)
      const response: SiteResponse = { site: result.site, mode, summary: result.summary }
      return jsonResponse(200, response)
    }

    throw new HttpError(404, 'Not found.')
  }

  return async (req, ip) => {
    try {
      return await route(req, ip)
    } catch (error) {
      const status = error instanceof HttpError ? error.status : 502
      const message = error instanceof Error ? error.message : 'Something went wrong.'
      if (!(error instanceof HttpError)) console.error('[api error]', message)
      return jsonResponse(status, { error: message } satisfies ErrorResponse)
    }
  }
}
