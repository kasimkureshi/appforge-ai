import { createApiHandler, type Env } from '../server/api'

/**
 * Cloudflare Worker entry point (wrangler.jsonc -> "main").
 * - /api/*  -> the same API code the local server uses (secrets come from Cloudflare settings)
 * - others  -> the built website files (wrangler.jsonc already sends these straight to the
 *              static assets, but this fallback keeps it working if that setting is changed;
 *              it is also what makes the optional Cloudflare Pages build work)
 */

interface WorkerEnv {
  ASSETS: { fetch(request: Request): Promise<Response> }
  [setting: string]: unknown
}

let currentEnv: Env = {}
const handleApi = createApiHandler({ getEnv: () => currentEnv })

const SECURITY_HEADERS: Record<string, string> = {
  'x-content-type-options': 'nosniff',
  'x-frame-options': 'DENY',
  'referrer-policy': 'no-referrer',
}

export default {
  async fetch(request: Request, env: WorkerEnv): Promise<Response> {
    const url = new URL(request.url)
    if (url.pathname.startsWith('/api/')) {
      currentEnv = env as unknown as Env
      return handleApi(request, request.headers.get('cf-connecting-ip') ?? 'unknown')
    }
    const asset = await env.ASSETS.fetch(request)
    const response = new Response(asset.body, asset)
    for (const [key, value] of Object.entries(SECURITY_HEADERS)) response.headers.set(key, value)
    return response
  },
}
