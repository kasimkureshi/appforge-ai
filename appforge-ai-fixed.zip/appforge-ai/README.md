# AppForge AI

Describe a website in plain English, get a multi-page site, preview it live, change it with follow-up
instructions, and download the source code as a ZIP.

Built with **React + TypeScript + Tailwind CSS** (the app) and a **Cloudflare Worker** (the secure server part
that keeps your AI key secret). Works in **demo mode with no API key**.

---

## Deploy from an Android phone (free, no computer)

You need two free accounts: **GitHub** (stores the files) and **Cloudflare** (hosts and builds the site).
Use Chrome. If a page looks cramped or a button is missing, tap Chrome's **⋮ menu → Desktop site**.

### Part 1: Put the ZIP on GitHub

1. Go to **github.com** and sign up or sign in.
2. Tap **+** (top right) → **New repository**.
3. **Repository name:** `appforge-ai`. Choose **Public** or **Private** (either works). Tap **Create repository**.
4. On the new empty repository page, tap **uploading an existing file** (or **Add file → Upload files**).
5. Tap **choose your files** and pick **`appforge-ai-fixed.zip`** from your phone's Downloads.
   Upload this one file exactly as it is. **Do not unzip it. Do not rename it.**
6. Wait for the upload bar to finish, then tap **Commit changes**.

You should now see `appforge-ai-fixed.zip` listed in the repository.
(If an older `appforge-ai.zip` is there, open it and delete it with the trash icon, so it can't confuse things.)

### Part 2: Create the Worker on Cloudflare

1. Go to **dash.cloudflare.com**, sign up or sign in (free plan is fine).
2. Open **Workers & Pages** → **Create** (or **Create application**).
3. Choose **Import a repository** (sometimes called **Connect to Git**) and connect your **GitHub** account.
   Allow access to your `appforge-ai` repository when GitHub asks.
4. Pick the **`appforge-ai`** repository.
5. Fill in the form exactly like this:

| Setting | Value |
| --- | --- |
| **Project / Worker name** | `appforge-ai` (**must be exactly this**, it has to match `wrangler.jsonc`) |
| **Production branch** | `main` |
| **Root directory** | `/` (leave as it is) |
| **Build command** | copy the **Build command** block below |
| **Deploy command** | copy the **Deploy command** block below |

   **Build command** (one line, copy all of it, the two `||` are two plain bars):

```
(unzip -oq appforge-ai-fixed.zip || python3 -m zipfile -e appforge-ai-fixed.zip .) && cd appforge-ai && npm install && npm run build
```

   **Deploy command:**

```
cd appforge-ai && npx wrangler deploy
```

6. Find **Build variables** (or **Advanced settings → Variables**) and add: name `NODE_VERSION`, value `22`.
7. Tap **Save and Deploy**. Watch the build log. It takes about 2 to 4 minutes.
8. When it says success, open your address. It looks like `https://appforge-ai.YOUR-NAME.workers.dev`.

### Part 3: Check that it works

Open your address and try this:

- [ ] You see the **AppForge AI** header with a **Demo mode** badge (not a white screen).
- [ ] Tap a bakery example, then **Generate website**. A live preview appears.
- [ ] Type `make it green` and tap **Apply**. The colours change.
- [ ] Tap **Code**, then **⬇ ZIP**. A ZIP downloads.
- [ ] Tap **Plans**. You see Free and Pro **₹299/month**.

### Part 4 (optional): Turn on real AI

Demo mode works with no key. For real AI generation:

1. Get an API key at **console.anthropic.com** (API use is billed separately from a Claude chat subscription).
2. In Cloudflare open your Worker → **Settings → Variables and Secrets → Add**.
3. **Type: Secret**, **Name:** `ANTHROPIC_API_KEY`, **Value:** your key. Tap **Deploy**.
4. Reload your site. The badge now says **AI mode**.

The key stays inside Cloudflare. It is never sent to your visitors' browsers.
Never put the key in GitHub, and never in a variable whose name starts with `VITE_` (those are public).
The server limits each visitor to 20 AI requests per 10 minutes to protect your bill.

### Updating the site later

Upload a new `appforge-ai-fixed.zip` to the repository (same file name, **Add file → Upload files**, then
**Commit changes**). Cloudflare rebuilds and redeploys automatically.

---

## If something goes wrong

**The page shows a message like "AppForge AI could not start".**
That is the app telling you what failed instead of a blank page. A line such as *"A script file failed to load"*
means the website files were not published. Open the Cloudflare build log and look for the first red error.

**Common build errors and fixes**

| What you see | What to do |
| --- | --- |
| `appforge-ai-fixed.zip: No such file` | The ZIP is not in the repository's main folder, or was renamed. Re-upload it, same exact name. |
| `Missing entry-point` / `wrangler.jsonc not found` | The unzip step did not run. Check the Build command was copied exactly. |
| Worker name mismatch error | Rename the Worker to `appforge-ai` (Settings → General), or edit the name in `wrangler.jsonc`. |
| `npm ERR!` during install | Tap **Retry deployment**. If it repeats, copy the first red error line and ask for help. |
| `The directory specified by "assets.directory" does not exist` | `npm run build` failed earlier. Scroll up in the log to find that first error. |
| Site loads but generating fails with an error about the key | The key is wrong or has no credit. Fix it under Variables and Secrets, or remove it to return to demo mode. |
| White page but no message | Hard refresh (Chrome ⋮ → reload). Then open your address with `/api/status` at the end. If you see `{"mode":"demo",...}` the Worker is fine and the problem is in the browser cache. |

---

## For people with a computer (optional)

Needs Node 20.19+ and internet.

```bash
npm install
npm run dev        # app: http://localhost:5173 (API: http://localhost:8787)
npm test           # automated tests
npm run build      # production build into dist/
npm run preview:cf # build and run it in Cloudflare's local Worker simulator
npm run deploy     # build and publish to Cloudflare (after: npx wrangler login)
```

`npm run build:pages` makes the older Cloudflare **Pages** style build (`dist/_worker.js`). It is optional and
not used by the steps above.

## How it is put together

| Path | What it does |
| --- | --- |
| `src/` | React + Tailwind interface (mobile-first) |
| `public/_headers` | Security headers for the website files |
| `worker/index.ts` | The Cloudflare Worker: handles `/api/*` only |
| `server/` | `api.ts` (the API, shared), `app.ts` (local Node server), `ai.ts` (AI call), rate limiting |
| `shared/` | Used by both sides: demo generator, validation, live-preview builder, ZIP writer |
| `wrangler.jsonc` | Cloudflare config: Worker name, entry file, website folder (`dist`), single-page-app routing |
| `tests/` | Automated tests, including checks of the Cloudflare config and for secrets in browser code |

## What was fixed in this version

- **Blank white page:** the project had no Cloudflare Workers configuration. The earlier `dist/_worker.js` file only
  works on Cloudflare *Pages*; on a Worker nothing told Cloudflare where the website files were or what code to run.
  `wrangler.jsonc` now does, with single-page-app routing, and only `/api/*` runs Worker code.
- **Silent failures:** `index.html` now shows "loading" and, if the app cannot start, a readable error on a dark
  background. A React error boundary shows a message and a Reload button if a screen crashes.
- **Tailwind:** the stylesheet now says explicitly where to scan for class names.
- **Build:** `npm run build` makes only the website, so no server code is published as a public file.
- Added `public/_headers`, `.node-version`, `wrangler` as a dev dependency, and new automated tests.

## Testing status (honest note)

Automated tests cover the demo generator, the API, the Worker, the ZIP writer, the Cloudflare config, the HTML shell
and a scan for secrets in browser code. The app was also driven end to end in a real browser. However, the build tools
(Vite, Tailwind, wrangler) could not be downloaded in the environment where this was prepared, so **the real
`npm run build` and a real Cloudflare deploy have not been run by the author.** Your first deploy is the first full
test. The troubleshooting table above covers the likeliest problems.

## Plans and money (current status)

- Free plan with an ad placeholder: built (`AdBanner.tsx`).
- Pro ₹299/month: pricing screen built; **real payments are not connected yet**.
- Premium features and custom services: listed in the app. The "Request a quote" button needs `VITE_CONTACT_EMAIL`
  (a public email address) to be set.
