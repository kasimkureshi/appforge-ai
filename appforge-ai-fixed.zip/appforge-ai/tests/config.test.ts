import assert from 'node:assert/strict'
import { existsSync, readdirSync, readFileSync, statSync } from 'node:fs'
import { join } from 'node:path'
import { describe, test } from 'node:test'

const root = new URL('..', import.meta.url).pathname
const read = (path: string) => readFileSync(join(root, path), 'utf8')

/** wrangler.jsonc allows // comments; remove whole-line comments, then parse. */
function readJsonc(path: string): any {
  return JSON.parse(
    read(path)
      .split('\n')
      .filter((line) => !line.trim().startsWith('//'))
      .join('\n'),
  )
}

function listFiles(dir: string): string[] {
  const out: string[] = []
  for (const name of readdirSync(join(root, dir))) {
    const rel = `${dir}/${name}`
    if (statSync(join(root, rel)).isDirectory()) out.push(...listFiles(rel))
    else out.push(rel)
  }
  return out
}

describe('Cloudflare Workers configuration', () => {
  const config = readJsonc('wrangler.jsonc')
  const pkg = JSON.parse(read('package.json'))

  test('names the Worker and its entry file, and the entry file exists', () => {
    assert.equal(config.name, 'appforge-ai')
    assert.ok(existsSync(join(root, config.main)), `${config.main} must exist`)
  })

  test('serves the folder Vite builds into, as a single-page app', () => {
    assert.equal(config.assets.directory, './dist')
    assert.match(read('vite.config.ts'), /outDir: 'dist'/)
    assert.equal(config.assets.not_found_handling, 'single-page-application')
    assert.equal(config.assets.binding, 'ASSETS') // worker/index.ts reads env.ASSETS
    assert.match(read('worker/index.ts'), /env\.ASSETS\.fetch/)
  })

  test('only /api/* is sent to the Worker code', () => {
    assert.deepEqual(config.assets.run_worker_first, ['/api/*'])
  })

  test('default build makes only the website (no public _worker.js)', () => {
    assert.equal(pkg.scripts.build, 'vite build')
    assert.ok(!pkg.scripts.build.includes('build-worker'))
    assert.ok(pkg.devDependencies.wrangler, 'wrangler is a dev dependency')
    for (const dep of ['vite', 'react', '@vitejs/plugin-react', 'tailwindcss', '@tailwindcss/vite']) {
      assert.ok(pkg.dependencies?.[dep] || pkg.devDependencies?.[dep], `${dep} is listed`)
    }
  })

  test('security headers file is in public/ so Vite copies it to dist/', () => {
    assert.match(read('public/_headers'), /X-Content-Type-Options: nosniff/)
  })
})

describe('web page shell', () => {
  const html = read('index.html')

  test('has a root element and the app script', () => {
    assert.match(html, /<div id="root">/)
    assert.match(html, /<script type="module" src="\/src\/main\.tsx"><\/script>/)
  })

  test('shows a message instead of a blank page when the app fails to start', () => {
    assert.match(html, /id="boot"/)
    assert.match(html, /could not start/)
    assert.match(html, /<noscript>/)
    assert.match(html, /background: #0b1020/) // never plain white
  })

  test('main.tsx wraps the app in an error boundary', () => {
    assert.match(read('src/main.tsx'), /<ErrorBoundary>/)
  })

  test('Tailwind is imported and told where to look', () => {
    const css = read('src/index.css')
    assert.match(css, /@import "tailwindcss"/)
    assert.match(css, /@source/)
    assert.match(read('vite.config.ts'), /tailwindcss\(\)/)
  })
})

describe('no secrets in browser code', () => {
  const browserFiles = [...listFiles('src'), ...listFiles('shared')].filter((f) => /\.(ts|tsx|css)$/.test(f))

  test('browser code never mentions the API key or imports server code', () => {
    for (const file of browserFiles) {
      const text = read(file)
      assert.ok(!/ANTHROPIC/i.test(text), `${file} mentions ANTHROPIC`)
      assert.ok(!/x-api-key/i.test(text), `${file} mentions x-api-key`)
      assert.ok(!/from ['"][./]*server\//.test(text), `${file} imports server code`)
      assert.ok(!/sk-ant-/.test(text), `${file} contains a key-like value`)
    }
  })

  test('only VITE_CONTACT_EMAIL is read from the environment in the browser', () => {
    const used = new Set<string>()
    for (const file of browserFiles) {
      for (const m of read(file).matchAll(/import\.meta\.env\.(\w+)/g)) used.add(m[1])
    }
    assert.deepEqual([...used], ['VITE_CONTACT_EMAIL'])
  })
})
