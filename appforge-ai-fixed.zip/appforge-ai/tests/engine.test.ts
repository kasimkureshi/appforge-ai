import assert from 'node:assert/strict'
import { test } from 'node:test'
import { applyDemoEdit, generateDemoSite } from '../shared/demo'
import { buildPreviewDoc, listPages } from '../shared/preview'
import { extractJson, isSafePath, validateSite } from '../shared/validate'

test('demo generator builds a multi-page site that passes validation', () => {
  const { site, summary } = generateDemoSite('A bakery called "Bright Bakes" with a green theme')
  assert.equal(site.name, 'Bright Bakes')
  assert.match(summary, /Bright Bakes/)
  const pages = listPages(site.files)
  assert.ok(pages.length >= 4, `expected 4+ pages, got ${pages.join(',')}`)
  assert.equal(pages[0], 'index.html')
  assert.ok(site.files.some((f) => f.path === 'styles.css'))
  assert.ok(site.files.some((f) => f.path === 'script.js'))
  validateSite(site)
  const css = site.files.find((f) => f.path === 'styles.css')!.content
  assert.match(css, /--accent: #16a34a;/)
})

test('demo generator picks a template from keywords', () => {
  assert.ok(generateDemoSite('an online store selling shoes').site.files.some((f) => f.path === 'products.html'))
  assert.ok(generateDemoSite('a personal portfolio for a photographer').site.files.some((f) => f.path === 'projects.html'))
  assert.ok(generateDemoSite('a gym website').site.files.some((f) => f.path === 'programs.html'))
  assert.ok(generateDemoSite('something for my company').site.files.some((f) => f.path === 'services.html'))
})

test('demo generator escapes HTML in names', () => {
  const { site } = generateDemoSite('a shop called "<script>alert(1)</script>"')
  const index = site.files.find((f) => f.path === 'index.html')!.content
  assert.ok(!index.includes('<script>alert(1)</script>'))
})

test('store pages have a working cart script and the script file parses', () => {
  const { site } = generateDemoSite('an online store')
  const script = site.files.find((f) => f.path === 'script.js')!.content
  assert.doesNotThrow(() => new Function(script))
  const products = site.files.find((f) => f.path === 'products.html')!.content
  assert.match(products, /js-cart/)
})

test('edit: colour, dark mode, rename, headline', () => {
  const { site } = generateDemoSite('a cafe called "Bean There"')
  const result = applyDemoEdit(site, 'make it purple, use dark mode, rename the site to Moon Cafe and change the headline to Coffee at midnight')
  assert.ok(result.changed)
  assert.equal(result.site.name, 'Moon Cafe')
  const css = result.site.files.find((f) => f.path === 'styles.css')!.content
  assert.match(css, /--accent: #7c3aed;/)
  const index = result.site.files.find((f) => f.path === 'index.html')!.content
  assert.match(index, /data-theme="dark"/)
  assert.match(index, /<h1>Coffee at midnight<\/h1>/)
  assert.ok(!index.includes('Bean There'))
  // original is not modified
  assert.equal(site.name, 'Bean There')
})

test('edit: add a page updates menus everywhere', () => {
  const { site } = generateDemoSite('a gym')
  const result = applyDemoEdit(site, 'add a pricing page')
  assert.ok(result.changed)
  assert.ok(result.site.files.some((f) => f.path === 'pricing.html'))
  for (const page of listPages(result.site.files)) {
    const html = result.site.files.find((f) => f.path === page)!.content
    assert.match(html, /href="pricing\.html"/, `${page} should link to pricing.html`)
  }
  const pricing = result.site.files.find((f) => f.path === 'pricing.html')!.content
  assert.match(pricing, /id="pricing"/)
  assert.match(pricing, /aria-current="page">Pricing/)
  validateSite(result.site)
})

test('edit: add sections, and do not add the same one twice', () => {
  const { site } = generateDemoSite('a restaurant')
  const first = applyDemoEdit(site, 'add a testimonials section')
  assert.match(first.site.files.find((f) => f.path === 'index.html')!.content, /id="testimonials"/)
  const second = applyDemoEdit(first.site, 'add a testimonials section')
  assert.match(second.summary, /already/)
  const count = second.site.files.find((f) => f.path === 'index.html')!.content.split('id="testimonials"').length - 1
  assert.equal(count, 1)
})

test('edit: unknown instructions leave the site unchanged and explain what works', () => {
  const { site } = generateDemoSite('a blog')
  const result = applyDemoEdit(site, 'make the logo spin in 3D')
  assert.equal(result.changed, false)
  assert.equal(result.site, site)
  assert.match(result.summary, /Demo mode understands/)
})

test('preview inlines css and js and supports page navigation', () => {
  const { site } = generateDemoSite('a portfolio')
  const doc = buildPreviewDoc(site.files, 'about.html')
  assert.match(doc, /<style>[\s\S]*--accent/)
  assert.match(doc, /<script>\(function/)
  assert.ok(!doc.includes('href="styles.css"'))
  assert.match(doc, /appforge-preview/)
  assert.match(doc, /About/)
  // unknown pages fall back to the home page
  assert.match(buildPreviewDoc(site.files, 'nope.html'), /<h1>Hi, I/)
})

test('validation rejects unsafe paths and bad data', () => {
  for (const bad of ['../x.html', '/etc/passwd.html', 'a\\b.html', 'run.exe', 'a//b.html', '']) {
    assert.equal(isSafePath(bad), false, bad)
  }
  assert.equal(isSafePath('css/site.css'), true)
  assert.throws(() => validateSite({ files: [{ path: '../x.html', content: '' }] }), /Unsafe/)
  assert.throws(() => validateSite({ files: [{ path: 'about.html', content: 'x' }] }), /index\.html/)
  assert.throws(() => validateSite({ files: [] }), /no files/)
  assert.throws(() => validateSite(null), /missing/)
  assert.throws(
    () =>
      validateSite({
        files: [
          { path: 'index.html', content: 'a' },
          { path: 'index.html', content: 'b' },
        ],
      }),
    /Duplicate/,
  )
})

test('extractJson tolerates code fences and extra text', () => {
  assert.deepEqual(extractJson('Here you go:\n```json\n{"a": 1}\n```\nEnjoy!'), { a: 1 })
  assert.throws(() => extractJson('no json here'), /did not contain/)
  assert.throws(() => extractJson('{broken'), /did not contain|not valid/)
})
