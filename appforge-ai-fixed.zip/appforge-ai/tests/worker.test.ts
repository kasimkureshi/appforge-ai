import assert from 'node:assert/strict'
import { describe, test } from 'node:test'
import worker from '../worker/index'

/** A stand-in for Cloudflare's static file server. */
const ASSETS = {
  fetch: async (req: Request) =>
    new Response(new URL(req.url).pathname === '/' ? '<h1>home</h1>' : 'missing', {
      status: new URL(req.url).pathname === '/' ? 200 : 404,
    }),
}

const call = (path: string, init?: RequestInit, env: Record<string, unknown> = {}) =>
  worker.fetch(new Request(`https://appforge.example${path}`, init), { ASSETS, ...env })

describe('Cloudflare worker', () => {
  test('serves the website files with security headers', async () => {
    const res = await call('/')
    assert.equal(await res.text(), '<h1>home</h1>')
    assert.equal(res.headers.get('x-content-type-options'), 'nosniff')
  })

  test('API works in demo mode without any key', async () => {
    const status = await (await call('/api/status')).json()
    assert.deepEqual(status, { mode: 'demo', aiConfigured: false })
    const res = await call('/api/generate', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ prompt: 'a portfolio for a painter called Mira' }),
    })
    const json = (await res.json()) as { site: { name: string; files: unknown[] }; mode: string }
    assert.equal(res.status, 200)
    assert.equal(json.mode, 'demo')
    assert.equal(json.site.name, 'Mira')
    assert.ok(json.site.files.length >= 6)
  })

  test('a secret set in Cloudflare switches to AI mode without leaking it', async () => {
    const res = await call('/api/status', undefined, { ANTHROPIC_API_KEY: 'sk-test-secret' })
    const text = await res.text()
    assert.match(text, /"mode":"ai"/)
    assert.ok(!text.includes('sk-test-secret'))
  })

  test('unknown API paths return JSON 404, not a web page', async () => {
    const res = await call('/api/does-not-exist')
    assert.equal(res.status, 404)
    assert.match(res.headers.get('content-type') ?? '', /application\/json/)
  })

  test('page addresses are passed to the static assets (single-page app)', async () => {
    let asked = ''
    const spy = { fetch: async (req: Request) => ((asked = new URL(req.url).pathname), new Response('<h1>app</h1>')) }
    const res = await worker.fetch(new Request('https://appforge.example/some/page'), { ASSETS: spy })
    assert.equal(asked, '/some/page')
    assert.equal(await res.text(), '<h1>app</h1>')
  })
})
