import assert from 'node:assert/strict'
import { test } from 'node:test'
import { generateDemoSite } from '../shared/demo'
import { buildSiteZip, crc32, createZip, zipFileName } from '../shared/zip'

/** A tiny independent ZIP reader, so the test does not trust the writer. */
function readZip(zip: Uint8Array): Map<string, string> {
  const view = new DataView(zip.buffer, zip.byteOffset, zip.byteLength)
  const decoder = new TextDecoder()
  let eocd = -1
  for (let i = zip.length - 22; i >= 0; i--) {
    if (view.getUint32(i, true) === 0x06054b50) {
      eocd = i
      break
    }
  }
  assert.ok(eocd >= 0, 'end of central directory found')
  const count = view.getUint16(eocd + 10, true)
  let pos = view.getUint32(eocd + 16, true)
  const out = new Map<string, string>()
  for (let n = 0; n < count; n++) {
    assert.equal(view.getUint32(pos, true), 0x02014b50, 'central directory entry signature')
    const crc = view.getUint32(pos + 16, true)
    const size = view.getUint32(pos + 24, true)
    const nameLen = view.getUint16(pos + 28, true)
    const extraLen = view.getUint16(pos + 30, true)
    const commentLen = view.getUint16(pos + 32, true)
    const localOffset = view.getUint32(pos + 42, true)
    const name = decoder.decode(zip.subarray(pos + 46, pos + 46 + nameLen))
    assert.equal(view.getUint32(localOffset, true), 0x04034b50, 'local header signature')
    const localNameLen = view.getUint16(localOffset + 26, true)
    const localExtraLen = view.getUint16(localOffset + 28, true)
    const start = localOffset + 30 + localNameLen + localExtraLen
    const data = zip.subarray(start, start + size)
    assert.equal(crc32(data), crc, `CRC matches for ${name}`)
    out.set(name, decoder.decode(data))
    pos += 46 + nameLen + extraLen + commentLen
  }
  return out
}

test('crc32 matches the standard test vector', () => {
  assert.equal(crc32(new TextEncoder().encode('123456789')), 0xcbf43926)
})

test('createZip round-trips file names and contents (including unicode)', () => {
  const files = [
    { path: 'index.html', content: '<h1>Hello ✓ नमस्ते</h1>' },
    { path: 'css/site.css', content: 'body{color:red}' },
    { path: 'empty.txt', content: '' },
  ]
  const read = readZip(createZip(files))
  assert.equal(read.size, 3)
  for (const f of files) assert.equal(read.get(f.path), f.content)
})

test('buildSiteZip contains every site file plus a README', () => {
  const { site } = generateDemoSite('a bakery called "Bright Bakes"')
  const read = readZip(buildSiteZip(site))
  for (const f of site.files) assert.equal(read.get(f.path), f.content, f.path)
  assert.match(read.get('README.md') ?? '', /Bright Bakes/)
  assert.match(read.get('README.md') ?? '', /index\.html/)
})

test('zipFileName makes a safe file name', () => {
  assert.equal(zipFileName({ name: 'Bright Bakes!', description: '', files: [] }), 'bright-bakes.zip')
  assert.equal(zipFileName({ name: '???', description: '', files: [] }), 'website.zip')
})
