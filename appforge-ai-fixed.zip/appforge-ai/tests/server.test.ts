import assert from 'node:assert/strict'
import type { AddressInfo } from 'node:net'
import { after, before, describe, test } from 'node:test'
import type { Server } from 'node:http'
import { createApp } from '../server/app'
import type { FetchLike } from '../server/ai'
import { generateDemoSite } from '../shared/demo'

async function start(server: Server): Promise<string> {
  await new Promise<void>((resolve) => server.listen(0, '127.0.0.1', resolve))
  return `http://127.0.0.1:${(server.address() as AddressInfo).port}`
}

async function post(base: string, path: string, body: unknown): Promise<{ status: number; json: any }> {
  const res = await fetch(base + path, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
  })
  return { status: res.status, json: await res.json() }
}

describe('server in demo mode (no API key)', () => {
  let server: Server
  let base: string
  before(async () => {
    server = createApp({ env: {}, distDir: '/nonexistent-dist' })
    base = await start(server)
  })
  after(() => server.close())

  test('status reports demo mode', async () => {
    const res = await fetch(`${base}/api/status`)
    assert.deepEqual(await res.json(), { mode: 'demo', aiConfigured: false })
    assert.equal(res.headers.get('x-content-type-options'), 'nosniff')
  })

  test('generate returns a full site', async () => {
    const { status, json } = await post(base, '/api/generate', { prompt: 'a yoga studio called "Calm Flow"' })
    assert.equal(status, 200)
    assert.equal(json.mode, 'demo')
    assert.equal(json.site.name, 'Calm Flow')
    assert.ok(json.site.files.length >= 6)
  })

  test('edit changes the site', async () => {
    const { site } = generateDemoSite('a blog')
    const { status, json } = await post(base, '/api/edit', { site, instruction: 'make it orange' })
    assert.equal(status, 200)
    assert.match(json.site.files.find((f: any) => f.path === 'styles.css').content, /--accent: #ea580c;/)
  })

  test('bad input is rejected with clear messages', async () => {
    assert.equal((await post(base, '/api/generate', { prompt: '' })).status, 400)
    assert.equal((await post(base, '/api/generate', { prompt: 'x'.repeat(5000) })).status, 400)
    assert.equal((await post(base, '/api/edit', { site: { files: [] }, instruction: 'make it blue' })).status, 400)
    const notJson = await fetch(`${base}/api/generate`, { method: 'POST', body: 'hello' })
    assert.equal(notJson.status, 400)
    assert.equal((await fetch(`${base}/api/nope`)).status, 404)
  })

  test('unbuilt web app gives a helpful message', async () => {
    const res = await fetch(`${base}/`)
    assert.equal(res.status, 404)
    assert.match((await res.json()).error, /not built/)
  })
})

describe('server in AI mode (fake AI, no network)', () => {
  let server: Server
  let base: string
  const calls: { url: string; headers: Record<string, string>; body: any }[] = []

  const aiSite = {
    name: 'AI Site',
    description: 'Made by the fake AI',
    summary: 'Built a tiny site.',
    files: [
      { path: 'index.html', content: '<h1>AI</h1>' },
      { path: 'about.html', content: '<h1>About</h1>' },
    ],
  }

  const fakeFetch: FetchLike = async (url, init) => {
    calls.push({ url, headers: init.headers as Record<string, string>, body: JSON.parse(String(init.body)) })
    return new Response(
      JSON.stringify({ stop_reason: 'end_turn', content: [{ type: 'text', text: 'Sure!\n```json\n' + JSON.stringify(aiSite) + '\n```' }] }),
      { status: 200 },
    )
  }

  before(async () => {
    server = createApp({ env: { ANTHROPIC_API_KEY: 'sk-test-secret-key' }, fetchImpl: fakeFetch, distDir: '/nonexistent-dist' })
    base = await start(server)
  })
  after(() => server.close())

  test('status reports AI mode but never leaks the key', async () => {
    const res = await fetch(`${base}/api/status`)
    const text = await res.text()
    assert.match(text, /"mode":"ai"/)
    assert.ok(!text.includes('sk-test-secret-key'))
  })

  test('generate calls the AI from the server with the key in a header', async () => {
    const { status, json } = await post(base, '/api/generate', { prompt: 'a site about robots' })
    assert.equal(status, 200)
    assert.equal(json.mode, 'ai')
    assert.equal(json.site.name, 'AI Site')
    assert.equal(json.summary, 'Built a tiny site.')
    const call = calls.at(-1)!
    assert.equal(call.url, 'https://api.anthropic.com/v1/messages')
    assert.equal(call.headers['x-api-key'], 'sk-test-secret-key')
    assert.match(call.body.messages[0].content, /a site about robots/)
    assert.ok(!JSON.stringify(json).includes('sk-test-secret-key'))
  })

  test('forceDemo skips the AI', async () => {
    const before = calls.length
    const { json } = await post(base, '/api/generate', { prompt: 'a gym', forceDemo: true })
    assert.equal(json.mode, 'demo')
    assert.equal(calls.length, before)
  })

  test('edit sends the current site and the instruction to the AI', async () => {
    const { site } = generateDemoSite('a blog')
    const { status, json } = await post(base, '/api/edit', { site, instruction: 'add a contact form' })
    assert.equal(status, 200)
    assert.equal(json.mode, 'ai')
    assert.match(calls.at(-1)!.body.messages[0].content, /add a contact form/)
  })
})

describe('server error handling', () => {
  test('AI failures become clear errors (and do not leak the key)', async () => {
    const failing: FetchLike = async () => new Response('{"error":"nope"}', { status: 401 })
    const server = createApp({ env: { ANTHROPIC_API_KEY: 'sk-test-secret-key' }, fetchImpl: failing })
    const base = await start(server)
    const { status, json } = await post(base, '/api/generate', { prompt: 'a site' })
    assert.equal(status, 502)
    assert.match(json.error, /API key was rejected/)
    assert.ok(!JSON.stringify(json).includes('sk-test-secret-key'))
    server.close()
  })

  test('garbage from the AI is rejected, not shown', async () => {
    const garbage: FetchLike = async () =>
      new Response(JSON.stringify({ content: [{ type: 'text', text: '{"files":[{"path":"../evil.html","content":"x"}]}' }] }), { status: 200 })
    const server = createApp({ env: { ANTHROPIC_API_KEY: 'k' }, fetchImpl: garbage })
    const base = await start(server)
    const { status, json } = await post(base, '/api/generate', { prompt: 'a site' })
    assert.equal(status, 502)
    assert.match(json.error, /Unsafe/)
    server.close()
  })

  test('rate limit kicks in', async () => {
    const server = createApp({ env: { ANTHROPIC_API_KEY: 'k', AI_RATE_LIMIT: '2' }, fetchImpl: async () => new Response('{}', { status: 500 }) })
    const base = await start(server)
    const statuses: number[] = []
    for (let i = 0; i < 3; i++) statuses.push((await post(base, '/api/generate', { prompt: 'a site' })).status)
    assert.deepEqual(statuses, [502, 502, 429])
    server.close()
  })
})
