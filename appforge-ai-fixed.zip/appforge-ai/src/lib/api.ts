import { applyDemoEdit, generateDemoSite } from '../../shared/demo'
import type { Site, SiteResponse, StatusResponse } from '../../shared/types'

/**
 * Talks to our own server (/api/...). The AI key never reaches the browser:
 * only the server knows it. If the server cannot be reached at all, we fall
 * back to the built-in demo generator so the app still works.
 */

async function readError(res: Response): Promise<string> {
  try {
    const data = (await res.json()) as { error?: string }
    if (data.error) return data.error
  } catch {
    /* ignore */
  }
  return `Request failed (status ${res.status}).`
}

/** Thrown when there is no API at all (for example the site is on a plain static host). */
class ApiUnavailable extends Error {}

function looksLikeApi(res: Response): boolean {
  return (res.headers.get('content-type') ?? '').includes('application/json')
}

async function post(path: string, body: unknown): Promise<SiteResponse> {
  const res = await fetch(path, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
  })
  // 404/405 or a non-JSON answer means there is no server behind /api: use the built-in demo instead.
  if (!looksLikeApi(res) && (res.status === 404 || res.status === 405 || res.ok)) throw new ApiUnavailable()
  if (!res.ok) throw new Error(await readError(res))
  return (await res.json()) as SiteResponse
}

export async function getStatus(): Promise<StatusResponse> {
  try {
    const res = await fetch('/api/status')
    if (!res.ok || !looksLikeApi(res)) throw new Error()
    return (await res.json()) as StatusResponse
  } catch {
    return { mode: 'demo', aiConfigured: false }
  }
}

function isNetworkError(error: unknown): boolean {
  // fetch() throws TypeError when the server is unreachable
  return error instanceof TypeError || error instanceof ApiUnavailable
}

export async function generateSite(prompt: string, forceDemo: boolean): Promise<SiteResponse> {
  try {
    return await post('/api/generate', { prompt, forceDemo })
  } catch (error) {
    if (!isNetworkError(error)) throw error
    const result = generateDemoSite(prompt)
    return { ...result, mode: 'demo' }
  }
}

export async function editSite(site: Site, instruction: string, forceDemo: boolean): Promise<SiteResponse> {
  try {
    return await post('/api/edit', { site, instruction, forceDemo })
  } catch (error) {
    if (!isNetworkError(error)) throw error
    const result = applyDemoEdit(site, instruction)
    return { site: result.site, summary: result.summary, mode: 'demo' }
  }
}
