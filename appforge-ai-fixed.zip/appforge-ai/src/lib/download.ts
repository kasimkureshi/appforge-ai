import { buildSiteZip, zipFileName } from '../../shared/zip'
import type { Site } from '../../shared/types'

/** Builds the ZIP in the browser and starts the download (works on Android Chrome). */
export function downloadSiteZip(site: Site): void {
  const bytes = buildSiteZip(site)
  const blob = new Blob([bytes as BlobPart], { type: 'application/zip' })
  const url = URL.createObjectURL(blob)
  const link = document.createElement('a')
  link.href = url
  link.download = zipFileName(site)
  document.body.appendChild(link)
  link.click()
  link.remove()
  setTimeout(() => URL.revokeObjectURL(url), 10_000)
}
