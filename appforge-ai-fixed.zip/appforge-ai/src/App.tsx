import { useEffect, useState, type FormEvent } from 'react'
import type { Site, StatusResponse } from '../shared/types'
import { DEMO_EDIT_HELP } from '../shared/demo'
import { LIMITS } from '../shared/types'
import { editSite, generateSite, getStatus } from './lib/api'
import { downloadSiteZip } from './lib/download'
import Preview from './components/Preview'
import CodeView from './components/CodeView'
import Plans, { type Plan } from './components/Plans'
import AdBanner from './components/AdBanner'

type Tab = 'build' | 'preview' | 'code' | 'plans'
interface Message {
  role: 'you' | 'appforge'
  text: string
}

const EXAMPLES = [
  'A bakery website called Sweet Crumbs with a menu and contact form',
  'A dark mode portfolio for a photographer named Riya',
  'A fitness gym landing page in green with pricing',
]

function loadPlan(): Plan {
  try {
    return localStorage.getItem('appforge-plan') === 'pro' ? 'pro' : 'free'
  } catch {
    return 'free'
  }
}

export default function App() {
  const [status, setStatus] = useState<StatusResponse | null>(null)
  const [tab, setTab] = useState<Tab>('build')
  const [plan, setPlan] = useState<Plan>(loadPlan)
  const [prompt, setPrompt] = useState('')
  const [instruction, setInstruction] = useState('')
  const [site, setSite] = useState<Site | null>(null)
  const [messages, setMessages] = useState<Message[]>([])
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [forceDemo, setForceDemo] = useState(false)

  useEffect(() => {
    void getStatus().then(setStatus)
  }, [])

  function changePlan(next: Plan) {
    setPlan(next)
    try {
      localStorage.setItem('appforge-plan', next)
    } catch {
      /* storage can be blocked; the plan just won't be remembered */
    }
  }

  const demoOnly = status ? !status.aiConfigured || forceDemo : true

  async function run(task: () => Promise<{ site: Site; summary: string }>, userText: string, goPreview: boolean) {
    setBusy(true)
    setError('')
    setMessages((m) => [...m, { role: 'you', text: userText }])
    try {
      const result = await task()
      setSite(result.site)
      setMessages((m) => [...m, { role: 'appforge', text: result.summary }])
      if (goPreview) setTab('preview')
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Something went wrong.')
    } finally {
      setBusy(false)
    }
  }

  function onGenerate(e: FormEvent) {
    e.preventDefault()
    const text = prompt.trim()
    if (text.length < LIMITS.minPromptChars || busy) return
    void run(() => generateSite(text, forceDemo), text, true)
  }

  function onEdit(e: FormEvent) {
    e.preventDefault()
    const text = instruction.trim()
    if (!site || text.length < 2 || busy) return
    setInstruction('')
    void run(() => editSite(site, text, forceDemo), text, true)
  }

  const tabs: { id: Tab; label: string; needsSite?: boolean }[] = [
    { id: 'build', label: 'Build' },
    { id: 'preview', label: 'Preview', needsSite: true },
    { id: 'code', label: 'Code', needsSite: true },
    { id: 'plans', label: 'Plans' },
  ]

  // On large screens the Build panel is always visible next to the other views.
  const rightView: Tab = tab === 'build' ? 'preview' : tab

  return (
    <div className="mx-auto flex min-h-screen max-w-7xl flex-col gap-3 p-3 pb-24 lg:pb-6">
      <header className="flex items-center justify-between gap-2">
        <h1 className="text-xl font-bold">
          ⚒️ AppForge <span className="text-indigo-400">AI</span>
        </h1>
        <div className="flex items-center gap-2 text-xs">
          <span
            className={`rounded-full px-3 py-1 font-medium ${
              demoOnly ? 'bg-amber-500/20 text-amber-300' : 'bg-emerald-500/20 text-emerald-300'
            }`}
          >
            {demoOnly ? 'Demo mode' : 'AI mode'}
          </span>
          <span className="rounded-full bg-slate-800 px-3 py-1">{plan === 'pro' ? 'Pro' : 'Free'}</span>
        </div>
      </header>

      {plan === 'free' && <AdBanner />}

      {/* Desktop tab bar (mobile uses the bottom bar) */}
      <nav className="hidden gap-2 lg:flex" aria-label="Views">
        {tabs
          .filter((t) => t.id !== 'build')
          .map((t) => (
            <button
              key={t.id}
              disabled={t.needsSite && !site}
              onClick={() => setTab(t.id)}
              className={`rounded-lg px-4 text-sm font-medium disabled:opacity-40 ${
                rightView === t.id ? 'bg-indigo-500 text-white' : 'bg-slate-800 text-slate-300'
              }`}
            >
              {t.label}
            </button>
          ))}
        {site && (
          <button onClick={() => downloadSiteZip(site)} className="ml-auto rounded-lg bg-emerald-600 px-4 text-sm font-medium text-white">
            ⬇ Download ZIP
          </button>
        )}
      </nav>

      <main className="grid flex-1 gap-4 lg:grid-cols-[380px_1fr]">
        {/* LEFT: describe + edit */}
        <section className={`${tab === 'build' ? 'flex' : 'hidden'} flex-col gap-3 lg:flex`}>
          <form onSubmit={onGenerate} className="flex flex-col gap-2 rounded-2xl border border-slate-700 bg-slate-900 p-4">
            <label htmlFor="prompt" className="text-sm font-semibold">
              1. Describe your website or app
            </label>
            <textarea
              id="prompt"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              maxLength={LIMITS.maxPromptChars}
              rows={4}
              placeholder="Example: A bakery website called Sweet Crumbs with a menu and contact form"
              className="rounded-lg border border-slate-700 bg-slate-800 p-3 text-slate-100 placeholder:text-slate-500"
            />
            <div className="flex flex-wrap gap-2">
              {EXAMPLES.map((ex) => (
                <button
                  key={ex}
                  type="button"
                  onClick={() => setPrompt(ex)}
                  className="rounded-full bg-slate-800 px-3 py-1 text-left text-xs text-slate-300 hover:bg-slate-700"
                >
                  {ex}
                </button>
              ))}
            </div>
            <button
              type="submit"
              disabled={busy || prompt.trim().length < LIMITS.minPromptChars}
              className="rounded-lg bg-indigo-500 font-semibold text-white disabled:opacity-50"
            >
              {busy ? 'Working…' : site ? 'Generate a new website' : 'Generate website'}
            </button>
            {status?.aiConfigured && (
              <label className="flex items-center gap-2 text-xs text-slate-400">
                <input type="checkbox" checked={forceDemo} onChange={(e) => setForceDemo(e.target.checked)} />
                Use demo mode (no AI cost)
              </label>
            )}
          </form>

          {error && (
            <p role="alert" className="rounded-lg border border-red-500/40 bg-red-500/10 p-3 text-sm text-red-200">
              {error}
            </p>
          )}

          {site && (
            <form onSubmit={onEdit} className="flex flex-col gap-2 rounded-2xl border border-slate-700 bg-slate-900 p-4">
              <label htmlFor="edit" className="text-sm font-semibold">
                2. Change it with follow-up instructions
              </label>
              <div className="flex gap-2">
                <input
                  id="edit"
                  value={instruction}
                  onChange={(e) => setInstruction(e.target.value)}
                  maxLength={LIMITS.maxInstructionChars}
                  placeholder='Try: "make it green"'
                  className="min-h-[44px] flex-1 rounded-lg border border-slate-700 bg-slate-800 px-3 text-base text-slate-100 placeholder:text-slate-500"
                />
                <button
                  type="submit"
                  disabled={busy || instruction.trim().length < 2}
                  className="rounded-lg bg-indigo-500 px-4 font-semibold text-white disabled:opacity-50"
                >
                  Apply
                </button>
              </div>
              {demoOnly && <p className="text-xs text-slate-400">{DEMO_EDIT_HELP}</p>}
            </form>
          )}

          {messages.length > 0 && (
            <ul className="space-y-2" aria-label="History">
              {messages.map((m, i) => (
                <li
                  key={i}
                  className={`max-w-[90%] rounded-2xl px-3 py-2 text-sm ${
                    m.role === 'you' ? 'ml-auto bg-indigo-600 text-white' : 'bg-slate-800 text-slate-200'
                  }`}
                >
                  {m.text}
                </li>
              ))}
            </ul>
          )}
        </section>

        {/* RIGHT: preview / code / plans */}
        <section className={`${tab === 'build' ? 'hidden' : 'block'} min-w-0 lg:block`}>
          {rightView === 'plans' ? (
            <Plans plan={plan} onChangePlan={changePlan} />
          ) : !site ? (
            <div className="flex min-h-[40vh] items-center justify-center rounded-2xl border border-dashed border-slate-700 p-6 text-center text-slate-400">
              Your website will appear here. Describe it on the left and tap Generate.
            </div>
          ) : rightView === 'code' ? (
            <CodeView site={site} />
          ) : (
            <Preview site={site} />
          )}
        </section>
      </main>

      {/* Mobile bottom bar */}
      <nav
        className="fixed inset-x-0 bottom-0 z-10 grid grid-cols-5 border-t border-slate-700 bg-slate-950/95 backdrop-blur lg:hidden"
        aria-label="Main"
      >
        {tabs.map((t) => (
          <button
            key={t.id}
            disabled={t.needsSite && !site}
            onClick={() => setTab(t.id)}
            className={`min-h-[56px] text-xs font-medium disabled:opacity-40 ${
              tab === t.id ? 'text-indigo-400' : 'text-slate-400'
            }`}
          >
            {t.label}
          </button>
        ))}
        <button
          disabled={!site}
          onClick={() => site && downloadSiteZip(site)}
          className="min-h-[56px] text-xs font-medium text-emerald-400 disabled:opacity-40"
        >
          ⬇ ZIP
        </button>
      </nav>
    </div>
  )
}
