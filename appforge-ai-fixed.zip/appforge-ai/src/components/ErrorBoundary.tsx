import { Component, type ErrorInfo, type ReactNode } from 'react'

/** If any screen crashes, show a readable message with a reload button instead of a blank page. */
export default class ErrorBoundary extends Component<{ children: ReactNode }, { error: Error | null }> {
  state: { error: Error | null } = { error: null }

  static getDerivedStateFromError(error: Error) {
    return { error }
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    console.error('AppForge AI crashed:', error, info.componentStack)
  }

  render() {
    if (!this.state.error) return this.props.children
    return (
      <div role="alert" style={{ padding: 24, color: '#e5e7eb' }}>
        <h1 style={{ fontSize: 20, fontWeight: 700 }}>Something went wrong</h1>
        <p style={{ margin: '8px 0' }}>AppForge AI hit an unexpected problem. Reloading usually fixes it.</p>
        <pre style={{ whiteSpace: 'pre-wrap', background: '#111827', padding: 10, borderRadius: 8, fontSize: 12 }}>
          {this.state.error.message}
        </pre>
        <button
          onClick={() => window.location.reload()}
          style={{ marginTop: 12, padding: '10px 16px', borderRadius: 8, background: '#6366f1', color: '#fff', border: 0 }}
        >
          Reload
        </button>
      </div>
    )
  }
}
