/**
 * Placeholder for the Free plan's ads. To show real ads later, paste your ad
 * network's code here (for example Google AdSense) after you have an approved account.
 */
export default function AdBanner() {
  return (
    <div
      role="complementary"
      aria-label="Advertisement"
      className="rounded-xl border border-dashed border-slate-600 bg-slate-900 p-3 text-center text-xs text-slate-400"
    >
      <span className="mr-2 rounded bg-slate-700 px-1.5 py-0.5 text-[10px] uppercase tracking-wide">Ad</span>
      Your ad goes here. Pro removes ads.
    </div>
  )
}
