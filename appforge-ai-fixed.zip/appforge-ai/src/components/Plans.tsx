export type Plan = 'free' | 'pro'

const CONTACT_EMAIL = (import.meta.env.VITE_CONTACT_EMAIL as string | undefined) ?? ''

interface Props {
  plan: Plan
  onChangePlan: (plan: Plan) => void
}

const FREE = ['Generate and preview websites', 'Edit with follow-up instructions', 'Download source code (ZIP)', 'Shows ads']
const PRO = ['Everything in Free', 'No ads', 'Priority AI generation', 'Premium templates (coming soon)', 'Publish to your own domain (coming soon)']

export default function Plans({ plan, onChangePlan }: Props) {
  const mail = CONTACT_EMAIL
    ? `mailto:${CONTACT_EMAIL}?subject=${encodeURIComponent('Custom website request')}`
    : ''

  return (
    <div className="grid gap-4 md:grid-cols-3">
      <section className="rounded-2xl border border-slate-700 bg-slate-900 p-5">
        <h3 className="text-lg font-semibold">Free</h3>
        <p className="mt-1 text-3xl font-bold">₹0</p>
        <ul className="mt-3 space-y-1 text-sm text-slate-300">
          {FREE.map((f) => (
            <li key={f}>✓ {f}</li>
          ))}
        </ul>
        <button
          onClick={() => onChangePlan('free')}
          disabled={plan === 'free'}
          className="mt-4 w-full rounded-lg bg-slate-700 font-medium disabled:opacity-60"
        >
          {plan === 'free' ? 'Current plan' : 'Switch to Free'}
        </button>
      </section>

      <section className="rounded-2xl border border-indigo-500 bg-slate-900 p-5 ring-1 ring-indigo-500/40">
        <h3 className="text-lg font-semibold">Pro</h3>
        <p className="mt-1 text-3xl font-bold">
          ₹299<span className="text-base font-normal text-slate-400">/month</span>
        </p>
        <ul className="mt-3 space-y-1 text-sm text-slate-300">
          {PRO.map((f) => (
            <li key={f}>✓ {f}</li>
          ))}
        </ul>
        <button
          onClick={() => onChangePlan('pro')}
          disabled={plan === 'pro'}
          className="mt-4 w-full rounded-lg bg-indigo-500 font-medium text-white disabled:opacity-60"
        >
          {plan === 'pro' ? 'Pro preview is on' : 'Preview Pro (demo)'}
        </button>
        <p className="mt-2 text-xs text-slate-400">
          Real payments are not connected yet (Step 2+). This button only shows how the Pro view looks.
        </p>
      </section>

      <section className="rounded-2xl border border-slate-700 bg-slate-900 p-5">
        <h3 className="text-lg font-semibold">Custom service</h3>
        <p className="mt-1 text-sm text-slate-300">
          Want a hand-built website or app? Tell us what you need and get a quote.
        </p>
        {mail ? (
          <a
            href={mail}
            className="mt-4 flex min-h-[44px] items-center justify-center rounded-lg bg-emerald-600 font-medium text-white"
          >
            Request a quote
          </a>
        ) : (
          <p className="mt-4 rounded-lg bg-slate-800 p-3 text-xs text-slate-400">
            Set VITE_CONTACT_EMAIL in your .env file to turn this into a "Request a quote" email button.
          </p>
        )}
      </section>
    </div>
  )
}
