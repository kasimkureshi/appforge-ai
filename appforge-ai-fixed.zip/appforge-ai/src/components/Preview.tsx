import { useEffect, useMemo, useRef, useState } from 'react'
import { buildPreviewDoc, listPages } from '../../shared/preview'
import type { Site } from '../../shared/types'

/** Live preview of the generated site inside a sandboxed iframe, with working page-to-page links. */
export default function Preview({ site }: { site: Site }) {
  const pages = useMemo(() => listPages(site.files), [site.files])
  const [page, setPage] = useState('index.html')
  const frame = useRef<HTMLIFrameElement>(null)

  // If the current page disappears after an edit, go back home.
  useEffect(() => {
    if (!pages.includes(page)) setPage('index.html')
  }, [pages, page])

  // Links inside the preview ask us (via postMessage) to switch pages.
  useEffect(() => {
    function onMessage(event: MessageEvent) {
      if (event.source !== frame.current?.contentWindow) return
      const data = event.data as { source?: string; type?: string; page?: string } | null
      if (data?.source !== 'appforge-preview' || data.type !== 'navigate' || !data.page) return
      if (pages.includes(data.page)) setPage(data.page)
    }
    window.addEventListener('message', onMessage)
    return () => window.removeEventListener('message', onMessage)
  }, [pages])

  const doc = useMemo(() => buildPreviewDoc(site.files, page), [site.files, page])

  return (
    <div className="flex h-full flex-col gap-2">
      <div className="flex gap-2 overflow-x-auto pb-1" role="tablist" aria-label="Pages">
        {pages.map((p) => (
          <button
            key={p}
            role="tab"
            aria-selected={p === page}
            onClick={() => setPage(p)}
            className={`shrink-0 rounded-full px-4 text-sm font-medium ${
              p === page ? 'bg-indigo-500 text-white' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            {p}
          </button>
        ))}
      </div>
      <iframe
        ref={frame}
        title={`Preview of ${site.name}`}
        srcDoc={doc}
        sandbox="allow-scripts allow-forms"
        className="min-h-[60vh] w-full flex-1 rounded-xl border border-slate-700 bg-white lg:min-h-[70vh]"
      />
    </div>
  )
}
