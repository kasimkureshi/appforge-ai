import { useState } from 'react'
import type { Site } from '../../shared/types'

/** Read-only view of every generated file. */
export default function CodeView({ site }: { site: Site }) {
  const [path, setPath] = useState('index.html')
  const file = site.files.find((f) => f.path === path) ?? site.files[0]

  return (
    <div className="flex h-full flex-col gap-2">
      <select
        value={file.path}
        onChange={(e) => setPath(e.target.value)}
        aria-label="Choose a file"
        className="rounded-lg border border-slate-700 bg-slate-800 px-3 text-slate-100"
      >
        {site.files.map((f) => (
          <option key={f.path} value={f.path}>
            {f.path}
          </option>
        ))}
      </select>
      <pre className="min-h-[60vh] flex-1 overflow-auto rounded-xl border border-slate-700 bg-slate-950 p-3 text-xs leading-relaxed text-slate-200 lg:min-h-[70vh]">
        <code>{file.content}</code>
      </pre>
    </div>
  )
}
