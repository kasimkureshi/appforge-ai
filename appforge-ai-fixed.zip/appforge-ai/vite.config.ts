import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'

// In development the web app (port 5173) forwards /api calls to the server (port 8787).
export default defineConfig({
  base: '/', // the site lives at the root of its address (needed for Cloudflare)
  plugins: [react(), tailwindcss()],
  build: { outDir: 'dist', emptyOutDir: true },
  server: {
    host: true,
    proxy: { '/api': 'http://localhost:8787' },
  },
})
