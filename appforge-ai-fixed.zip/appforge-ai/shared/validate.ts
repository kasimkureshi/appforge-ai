import { LIMITS, type Site, type SiteFile } from './types'

const ALLOWED_EXTENSIONS = ['.html', '.css', '.js', '.json', '.svg', '.txt', '.md']

/**
 * A file path is safe when it is a short, relative path (like "css/site.css")
 * with an allowed extension. This blocks tricks such as "../../etc/passwd"
 * in AI-generated output or in ZIP files.
 */
export function isSafePath(path: unknown): path is string {
  if (typeof path !== 'string' || path.length === 0 || path.length > 100) return false
  if (path.startsWith('/') || path.includes('\\') || path.includes('\0')) return false
  const parts = path.split('/')
  if (parts.some((part) => part === '' || part === '.' || part === '..')) return false
  const lower = path.toLowerCase()
  return ALLOWED_EXTENSIONS.some((ext) => lower.endsWith(ext))
}

function byteLength(text: string): number {
  return new TextEncoder().encode(text).length
}

/** Checks that unknown data (from the AI or from the browser) is a valid Site. Throws a readable Error if not. */
export function validateSite(input: unknown): Site {
  if (!input || typeof input !== 'object') throw new Error('The website data is missing.')
  const raw = input as Record<string, unknown>

  const name =
    typeof raw.name === 'string' && raw.name.trim() ? raw.name.trim().slice(0, 80) : 'My Website'
  const description = typeof raw.description === 'string' ? raw.description.slice(0, 300) : ''

  if (!Array.isArray(raw.files) || raw.files.length === 0) {
    throw new Error('The website has no files.')
  }
  if (raw.files.length > LIMITS.maxFiles) {
    throw new Error(`The website has too many files (max ${LIMITS.maxFiles}).`)
  }

  const seen = new Set<string>()
  const files: SiteFile[] = []
  let total = 0

  for (const item of raw.files) {
    const entry = (item ?? {}) as Record<string, unknown>
    const path = entry.path
    const content = entry.content
    if (!isSafePath(path)) {
      throw new Error(`Unsafe or unsupported file path: ${String(path).slice(0, 60)}`)
    }
    if (typeof content !== 'string') throw new Error(`File ${path} has no text content.`)
    if (seen.has(path)) throw new Error(`Duplicate file: ${path}`)
    const size = byteLength(content)
    if (size > LIMITS.maxFileBytes) throw new Error(`File ${path} is too large.`)
    total += size
    if (total > LIMITS.maxTotalBytes) throw new Error('The website is too large.')
    seen.add(path)
    files.push({ path, content })
  }

  if (!seen.has('index.html')) throw new Error('The website must include an index.html file.')
  return { name, description, files }
}

/**
 * AI models sometimes wrap JSON in text or ``` fences.
 * We take everything from the first "{" to the last "}" and parse that.
 */
export function extractJson(text: string): unknown {
  const start = text.indexOf('{')
  const end = text.lastIndexOf('}')
  if (start === -1 || end <= start) throw new Error('The AI response did not contain website data.')
  try {
    return JSON.parse(text.slice(start, end + 1))
  } catch {
    throw new Error('The AI response was not valid JSON. Try again or simplify the request.')
  }
}
