import type { SiteFile } from './types'

/** All HTML pages of the site, with index.html first. */
export function listPages(files: SiteFile[]): string[] {
  const pages = files.map((f) => f.path).filter((p) => p.toLowerCase().endsWith('.html'))
  return pages.sort((a, b) => (a === 'index.html' ? -1 : b === 'index.html' ? 1 : a.localeCompare(b)))
}

function cleanRef(ref: string): string {
  return ref.split('#')[0].split('?')[0].replace(/^\.\//, '')
}

/** Makes text safe to place inside an inline <script> or <style> tag. */
function inlineSafe(text: string, tag: 'script' | 'style'): string {
  return text.replace(new RegExp(`</${tag}`, 'gi'), `<\\/${tag}`)
}

/**
 * The preview runs inside a sandboxed iframe, which cannot load sibling files.
 * So we inline the CSS and JS into the page, and add a small script that tells
 * the app when someone taps a link to another page (so navigation works).
 */
const NAVIGATION_SCRIPT = `<script>
document.addEventListener('click', function (e) {
  var a = e.target && e.target.closest ? e.target.closest('a[href]') : null;
  if (!a) return;
  var href = a.getAttribute('href') || '';
  if (href.charAt(0) === '#' || /^(mailto:|tel:|javascript:)/i.test(href)) return;
  e.preventDefault();
  if (/^https?:/i.test(href)) return;
  var page = href.split('#')[0].split('?')[0].replace(/^\\.\\//, '');
  parent.postMessage({ source: 'appforge-preview', type: 'navigate', page: page }, '*');
});
</script>`

export function buildPreviewDoc(files: SiteFile[], page: string): string {
  const byPath = new Map(files.map((f) => [f.path, f.content]))
  const target = byPath.has(page) ? page : 'index.html'
  let html = byPath.get(target) ?? '<!doctype html><p>This page does not exist.</p>'

  // <link rel="stylesheet" href="styles.css"> -> <style>...</style>
  html = html.replace(/<link\b[^>]*>/gi, (tag) => {
    if (!/rel=["']?stylesheet/i.test(tag)) return tag
    const href = /href=["']([^"']+)["']/i.exec(tag)?.[1]
    const css = href ? byPath.get(cleanRef(href)) : undefined
    return css === undefined ? tag : `<style>${inlineSafe(css, 'style')}</style>`
  })

  // <script src="script.js"></script> -> <script>...</script>
  html = html.replace(/<script\b([^>]*)\bsrc=["']([^"']+)["']([^>]*)>\s*<\/script>/gi, (tag, _a, src) => {
    const js = byPath.get(cleanRef(src))
    return js === undefined ? tag : `<script>${inlineSafe(js, 'script')}</script>`
  })

  return /<\/body>/i.test(html)
    ? html.replace(/<\/body>/i, () => `${NAVIGATION_SCRIPT}</body>`)
    : html + NAVIGATION_SCRIPT
}
