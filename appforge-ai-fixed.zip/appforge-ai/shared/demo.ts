import type { Site, SiteFile } from './types'

/**
 * DEMO MODE: a built-in website generator that needs no API key and no internet.
 * It picks a template from keywords in your description, then follow-up
 * instructions are applied with simple text rules.
 * The real AI mode (server/ai.ts) replaces this when an API key is configured.
 */

// ---------- helpers ----------

export function escapeHtml(text: string): string {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
}

function titleCase(text: string): string {
  return text.replace(/\b([a-z])/g, (_m, c: string) => c.toUpperCase())
}

function slugify(text: string): string {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
}

// ---------- colors ----------

const COLORS: Record<string, [string, string]> = {
  blue: ['#2563eb', '#1d4ed8'],
  green: ['#16a34a', '#15803d'],
  red: ['#dc2626', '#b91c1c'],
  purple: ['#7c3aed', '#6d28d9'],
  orange: ['#ea580c', '#c2410c'],
  pink: ['#db2777', '#be185d'],
  teal: ['#0d9488', '#0f766e'],
  yellow: ['#ca8a04', '#a16207'],
  indigo: ['#4f46e5', '#4338ca'],
  black: ['#111827', '#000000'],
}

function darken(hex: string): string {
  const n = parseInt(hex.slice(1), 16)
  const channel = (shift: number) =>
    Math.max(0, Math.round(((n >> shift) & 255) * 0.85))
      .toString(16)
      .padStart(2, '0')
  return `#${channel(16)}${channel(8)}${channel(0)}`
}

function findColor(text: string): [string, string] | null {
  const hex = /#([0-9a-f]{6})\b/i.exec(text)
  if (hex) {
    const base = `#${hex[1].toLowerCase()}`
    return [base, darken(base)]
  }
  const word = /\b(blue|green|red|purple|orange|pink|teal|yellow|indigo|black)\b/i.exec(text)
  return word ? COLORS[word[1].toLowerCase()] : null
}

// ---------- templates ----------

interface Item {
  icon: string
  title: string
  text: string
  meta?: string
}

interface Kind {
  id: string
  keywords: RegExp
  defaultName: string
  emoji: string
  accent: string
  heroTitle: (name: string) => string
  heroText: string
  cta: string
  listFile: string
  listLabel: string
  listIntro: string
  items: Item[]
  about: string[]
  stats: [string, string][]
  shop?: boolean
}

const KINDS: Kind[] = [
  {
    id: 'restaurant',
    keywords: /\b(restaurant|cafe|café|coffee|bakery|food|pizza|menu|biryani|diner|bistro|dessert)\b/i,
    defaultName: 'Tasty Corner',
    emoji: '🍽️',
    accent: 'orange',
    heroTitle: (n) => `Welcome to ${n}`,
    heroText: 'Hand-crafted dishes, warm hospitality and flavours you will come back for.',
    cta: 'Book a table',
    listFile: 'menu.html',
    listLabel: 'Menu',
    listIntro: 'Our most-loved dishes, cooked fresh every day.',
    items: [
      { icon: '🍕', title: 'Wood-fired Pizza', text: 'Thin crust, rich sauce and fresh basil.', meta: '₹349' },
      { icon: '🍝', title: 'Creamy Pasta', text: 'Slow-cooked sauce with herbs and parmesan.', meta: '₹299' },
      { icon: '🥗', title: 'Garden Salad', text: 'Crisp seasonal vegetables with a lemon dressing.', meta: '₹199' },
      { icon: '☕', title: 'Signature Coffee', text: 'Small-batch beans, brewed to order.', meta: '₹129' },
      { icon: '🍰', title: 'Chocolate Brownie', text: 'Warm, gooey and topped with ice cream.', meta: '₹149' },
      { icon: '🍔', title: 'Classic Burger', text: 'Juicy patty, toasted bun and crispy fries.', meta: '₹249' },
    ],
    about: [
      'We started as a tiny kitchen with one simple idea: great food should feel like home.',
      'Everything is made fresh each morning from local ingredients, and our team treats every guest like family.',
    ],
    stats: [['10+', 'Years serving'], ['40+', 'Dishes'], ['4.8★', 'Guest rating']],
  },
  {
    id: 'fitness',
    keywords: /\b(gym|fitness|workout|yoga|trainer|training|crossfit|health club)\b/i,
    defaultName: 'FitForge Gym',
    emoji: '💪',
    accent: 'red',
    heroTitle: (n) => `Train hard at ${n}`,
    heroText: 'Strength, cardio and coaching that fits your goals, whatever your level.',
    cta: 'Start your free trial',
    listFile: 'programs.html',
    listLabel: 'Programs',
    listIntro: 'Pick a program and our coaches will guide you every step.',
    items: [
      { icon: '🏋️', title: 'Strength Training', text: 'Build muscle with structured progressive overload.', meta: '₹1,499/mo' },
      { icon: '🏃', title: 'Cardio Blast', text: 'High-energy sessions to boost stamina and burn fat.', meta: '₹999/mo' },
      { icon: '🧘', title: 'Yoga & Mobility', text: 'Improve flexibility, posture and recovery.', meta: '₹799/mo' },
      { icon: '🥗', title: 'Diet Coaching', text: 'Simple meal plans that match your training.', meta: '₹1,199/mo' },
      { icon: '🥊', title: 'Boxing Fundamentals', text: 'Learn technique, footwork and conditioning.', meta: '₹1,299/mo' },
      { icon: '👥', title: 'Personal Training', text: 'One-to-one coaching built around you.', meta: '₹3,499/mo' },
    ],
    about: [
      'We believe discipline beats motivation. Our coaches help you build habits that last.',
      'Whether you are lifting for the first time or training for a competition, there is a place for you here.',
    ],
    stats: [['500+', 'Members'], ['12', 'Expert coaches'], ['6am-10pm', 'Open daily']],
  },
  {
    id: 'store',
    keywords: /\b(store|shop|ecommerce|e-commerce|boutique|clothing|products|sell|selling|marketplace)\b/i,
    defaultName: 'Urban Cart',
    emoji: '🛍️',
    accent: 'purple',
    heroTitle: (n) => `Shop the best at ${n}`,
    heroText: 'Quality products, honest prices and fast delivery to your door.',
    cta: 'Shop now',
    listFile: 'products.html',
    listLabel: 'Products',
    listIntro: 'Hand-picked favourites. Tap "Add to cart" to try the cart.',
    items: [
      { icon: '👟', title: 'Running Shoes', text: 'Lightweight, breathable and built for daily miles.', meta: '₹2,499' },
      { icon: '🎧', title: 'Wireless Earbuds', text: 'Clear sound with up to 24 hours of battery.', meta: '₹1,799' },
      { icon: '🎒', title: 'Everyday Backpack', text: 'Water-resistant with a padded laptop pocket.', meta: '₹1,299' },
      { icon: '⌚', title: 'Smart Watch', text: 'Track steps, sleep and notifications.', meta: '₹3,999' },
      { icon: '🧢', title: 'Classic Cap', text: 'Soft cotton and an adjustable fit.', meta: '₹499' },
      { icon: '🕶️', title: 'Sunglasses', text: 'UV-protected lenses with a durable frame.', meta: '₹899' },
    ],
    about: [
      'We started this store to make good products easier to find and fairer to buy.',
      'Every item is checked by our team, and if you are not happy you can return it within 7 days.',
    ],
    stats: [['5,000+', 'Orders shipped'], ['7 days', 'Easy returns'], ['4.7★', 'Customer rating']],
    shop: true,
  },
  {
    id: 'portfolio',
    keywords: /\b(portfolio|resume|personal|developer|designer|photographer|freelancer|freelance|artist)\b/i,
    defaultName: 'Alex Morgan',
    emoji: '✨',
    accent: 'indigo',
    heroTitle: (n) => `Hi, I'm ${n}`,
    heroText: 'I design and build clean, fast and friendly digital experiences.',
    cta: 'Hire me',
    listFile: 'projects.html',
    listLabel: 'Projects',
    listIntro: 'A few things I have built recently.',
    items: [
      { icon: '🌐', title: 'Landing Page Redesign', text: 'Doubled sign-ups with a clearer story.', meta: 'Web' },
      { icon: '📱', title: 'Fitness Tracker App', text: 'A simple mobile-first habit tracker.', meta: 'App' },
      { icon: '🛒', title: 'Online Store', text: 'Fast checkout and a clean product catalogue.', meta: 'Web' },
      { icon: '🎨', title: 'Brand Identity', text: 'Logo, colours and a small design system.', meta: 'Design' },
      { icon: '📊', title: 'Analytics Dashboard', text: 'Charts that make data easy to act on.', meta: 'Web' },
      { icon: '🎬', title: 'Video Editing Reel', text: 'Short-form edits for creators.', meta: 'Video' },
    ],
    about: [
      'I enjoy turning messy ideas into simple, useful products.',
      'I work with founders and small teams, and I care about speed, clarity and good details.',
    ],
    stats: [['40+', 'Projects'], ['5 yrs', 'Experience'], ['100%', 'Remote friendly']],
  },
  {
    id: 'blog',
    keywords: /\b(blog|news|magazine|journal|articles|newsletter)\b/i,
    defaultName: 'The Daily Note',
    emoji: '📝',
    accent: 'teal',
    heroTitle: (n) => `Stories worth reading on ${n}`,
    heroText: 'Practical guides, honest opinions and ideas worth thinking about.',
    cta: 'Read the latest',
    listFile: 'articles.html',
    listLabel: 'Articles',
    listIntro: 'Fresh writing, published every week.',
    items: [
      { icon: '🚀', title: 'How to Start Anything', text: 'A simple way to begin when you feel stuck.', meta: '5 min read' },
      { icon: '🧠', title: 'Learning Faster', text: 'Small habits that make knowledge stick.', meta: '7 min read' },
      { icon: '💡', title: 'Ideas Worth Building', text: 'How to test an idea before spending money.', meta: '6 min read' },
      { icon: '🌱', title: 'Building Better Habits', text: 'Why tiny actions beat big plans.', meta: '4 min read' },
      { icon: '🎯', title: 'Setting Goals That Work', text: 'Turn vague wishes into weekly steps.', meta: '8 min read' },
      { icon: '📚', title: 'Books That Changed Me', text: 'Ten reads and the lessons I kept.', meta: '9 min read' },
    ],
    about: [
      'This blog is a notebook that happens to be public.',
      'We write about learning, building and living well, in plain language and without the hype.',
    ],
    stats: [['120+', 'Articles'], ['10k', 'Monthly readers'], ['Weekly', 'New posts']],
  },
  {
    id: 'business',
    keywords: /.*/,
    defaultName: 'Nova Studio',
    emoji: '🚀',
    accent: 'blue',
    heroTitle: (n) => `Grow faster with ${n}`,
    heroText: 'We help ambitious teams design, build and launch products people love.',
    cta: 'Get a free quote',
    listFile: 'services.html',
    listLabel: 'Services',
    listIntro: 'Everything you need to go from idea to launch.',
    items: [
      { icon: '💡', title: 'Strategy & Consulting', text: 'Clear plans and priorities for your next stage.', meta: '' },
      { icon: '🖥️', title: 'Web Development', text: 'Fast, secure and mobile-friendly websites.', meta: '' },
      { icon: '🎨', title: 'UI/UX Design', text: 'Interfaces that feel simple and look great.', meta: '' },
      { icon: '📣', title: 'Digital Marketing', text: 'Content and campaigns that bring real customers.', meta: '' },
      { icon: '🔒', title: 'Security Review', text: 'Find and fix weak spots before attackers do.', meta: '' },
      { icon: '🤝', title: 'Ongoing Support', text: 'A friendly team on call after launch.', meta: '' },
    ],
    about: [
      'We are a small, senior team that cares more about outcomes than buzzwords.',
      'We work closely with our clients, share progress every week and keep things simple.',
    ],
    stats: [['60+', 'Projects delivered'], ['4 yrs', 'In business'], ['98%', 'Happy clients']],
  },
]

function detectKind(prompt: string): Kind {
  return KINDS.find((k) => k.keywords.test(prompt)) ?? KINDS[KINDS.length - 1]
}

function extractName(prompt: string, fallback: string): string {
  const quoted = /["“]([^"”]{2,40})["”]/.exec(prompt)
  if (quoted) return quoted[1].trim()
  const named =
    /\b(?:called|named)\s+['"“]?([A-Za-z0-9][A-Za-z0-9&' -]{1,38}?)['"”]?(?=\s+(?:that|which|with|for|where|in|and|to|selling|offering|is)\b|[,.!?]|$)/i.exec(
      prompt,
    )
  if (named) return named[1].trim()
  return fallback
}

// ---------- shared files ----------

const STYLES_CSS = `:root {
  --accent: #2563eb;
  --accent-dark: #1d4ed8;
  --bg: #ffffff;
  --surface: #f8fafc;
  --text: #0f172a;
  --muted: #475569;
  --border: #e2e8f0;
  --radius: 14px;
}
[data-theme="dark"] {
  --bg: #0b1020;
  --surface: #121a33;
  --text: #e8ecf8;
  --muted: #a3adc9;
  --border: #25304f;
}
* { box-sizing: border-box; }
html { scroll-behavior: smooth; }
body {
  margin: 0;
  font-family: system-ui, -apple-system, "Segoe UI", Roboto, sans-serif;
  background: var(--bg);
  color: var(--text);
  line-height: 1.6;
}
.container { width: min(1100px, 92%); margin-inline: auto; }
a { color: var(--accent); }
.site-header { position: sticky; top: 0; background: var(--bg); border-bottom: 1px solid var(--border); z-index: 10; }
.nav { display: flex; align-items: center; justify-content: space-between; padding: 0.9rem 0; gap: 1rem; flex-wrap: wrap; }
.brand { font-weight: 800; font-size: 1.2rem; color: var(--text); text-decoration: none; }
.nav-links { display: flex; gap: 1.25rem; list-style: none; margin: 0; padding: 0; align-items: center; }
.nav-links a { color: var(--muted); text-decoration: none; font-weight: 600; }
.nav-links a:hover, .nav-links a[aria-current="page"] { color: var(--accent); }
.nav-toggle { display: none; background: none; border: 1px solid var(--border); color: var(--text); border-radius: 10px; font-size: 1.25rem; padding: 0.25rem 0.65rem; cursor: pointer; }
.hero { padding: 4.5rem 0 3.5rem; background: linear-gradient(135deg, var(--surface), var(--bg)); }
.hero h1 { font-size: clamp(2rem, 6vw, 3.4rem); line-height: 1.1; margin: 0 0 1rem; }
.hero p { color: var(--muted); font-size: 1.15rem; max-width: 40rem; margin: 0 0 1.5rem; }
.btn { display: inline-block; background: var(--accent); color: #fff; padding: 0.8rem 1.4rem; border-radius: 999px; border: 0; font-weight: 700; text-decoration: none; cursor: pointer; font-size: 1rem; }
.btn:hover { background: var(--accent-dark); }
.btn.small { padding: 0.45rem 1rem; font-size: 0.9rem; }
.section { padding: 3rem 0; }
.section h2 { font-size: 1.8rem; margin: 0 0 0.5rem; }
.lead { color: var(--muted); margin: 0 0 1.75rem; }
.grid { display: grid; gap: 1.25rem; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); }
.card { background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius); padding: 1.4rem; margin: 0; }
.card .icon { font-size: 2rem; }
.card h3 { margin: 0.5rem 0 0.25rem; }
.card p { color: var(--muted); margin: 0.25rem 0 1rem; }
.meta { font-weight: 800; color: var(--accent); }
.stats { display: flex; flex-wrap: wrap; gap: 2rem; margin-top: 2rem; }
.stats b { display: block; font-size: 1.8rem; color: var(--accent); }
.cta { background: var(--accent); color: #fff; text-align: center; padding: 3rem 1rem; border-radius: var(--radius); }
.cta h2 { margin-top: 0; }
.cta .btn { background: #fff; color: var(--accent-dark); }
form { display: grid; gap: 1rem; max-width: 560px; }
label { font-weight: 600; display: grid; gap: 0.35rem; }
input, textarea { font: inherit; padding: 0.75rem; border-radius: 10px; border: 1px solid var(--border); background: var(--bg); color: var(--text); }
.error { color: #dc2626; font-size: 0.9rem; min-height: 1.1em; }
.success { background: #dcfce7; color: #166534; padding: 1rem; border-radius: 10px; }
details.card summary { cursor: pointer; font-weight: 700; }
.site-footer { border-top: 1px solid var(--border); padding: 2rem 0; color: var(--muted); margin-top: 3rem; }
.cart-pill { background: var(--surface); border: 1px solid var(--border); padding: 0.25rem 0.7rem; border-radius: 999px; font-weight: 700; }
@media (max-width: 720px) {
  .nav-toggle { display: block; }
  .nav-links { display: none; width: 100%; flex-direction: column; align-items: flex-start; gap: 0.75rem; padding-bottom: 0.75rem; }
  .nav-links.open { display: flex; }
}
`

const SCRIPT_JS = String.raw`(function () {
  // Mobile menu
  var toggle = document.getElementById('nav-toggle');
  var links = document.getElementById('nav-links');
  if (toggle && links) {
    toggle.addEventListener('click', function () {
      var open = links.classList.toggle('open');
      toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
  }

  // Footer year
  var year = document.getElementById('year');
  if (year) year.textContent = new Date().getFullYear();

  // Simple cart (remembered for the browser session)
  var badge = document.getElementById('cart-count');
  function loadCount() { try { return parseInt(sessionStorage.getItem('cart') || '0', 10) || 0; } catch (e) { return 0; } }
  function saveCount(n) { try { sessionStorage.setItem('cart', String(n)); } catch (e) {} }
  var count = loadCount();
  if (badge) badge.textContent = count;
  document.querySelectorAll('.js-cart').forEach(function (btn) {
    btn.addEventListener('click', function () {
      count += 1;
      saveCount(count);
      if (badge) badge.textContent = count;
      btn.textContent = 'Added ✓';
      setTimeout(function () { btn.textContent = 'Add to cart'; }, 1200);
    });
  });

  // Contact form with validation (demo only: nothing is sent anywhere)
  var form = document.getElementById('contact-form');
  if (form) {
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var ok = true;
      function check(field, valid, message) {
        var out = document.getElementById(field + '-error');
        if (out) out.textContent = valid ? '' : message;
        if (!valid) ok = false;
      }
      check('name', form.elements['name'].value.trim().length >= 2, 'Please enter your name.');
      check('email', /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.elements['email'].value.trim()), 'Please enter a valid email.');
      check('message', form.elements['message'].value.trim().length >= 10, 'Message should be at least 10 characters.');
      var done = document.getElementById('form-success');
      if (done) done.hidden = !ok;
      if (ok) form.reset();
    });
  }

  // Newsletter form
  var news = document.getElementById('newsletter-form');
  if (news) {
    news.addEventListener('submit', function (e) {
      e.preventDefault();
      var done = document.getElementById('newsletter-success');
      if (done) done.hidden = false;
      news.reset();
    });
  }
})();
`

// ---------- page builders ----------

interface Spec {
  name: string
  kind: Kind
  dark: boolean
  pages: [file: string, label: string][]
}

function pageShell(spec: Spec, file: string, title: string, main: string): string {
  const name = escapeHtml(spec.name)
  const links = spec.pages
    .map(([f, label]) => `        <li><a href="${f}"${f === file ? ' aria-current="page"' : ''}>${escapeHtml(label)}</a></li>`)
    .join('\n')
  const cart = spec.kind.shop
    ? '\n        <li><span class="cart-pill">🛒 <b id="cart-count">0</b></span></li>'
    : ''
  return `<!doctype html>
<html lang="en"${spec.dark ? ' data-theme="dark"' : ''}>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>${escapeHtml(title)} - ${name}</title>
  <meta name="description" content="${name}: ${escapeHtml(spec.kind.heroText)}">
  <link rel="stylesheet" href="styles.css">
</head>
<body>
  <header class="site-header">
    <div class="container nav">
      <a class="brand" href="index.html">${spec.kind.emoji} ${name}</a>
      <button class="nav-toggle" id="nav-toggle" aria-label="Toggle menu" aria-expanded="false">☰</button>
      <ul class="nav-links" id="nav-links">
${links}${cart}
      </ul>
    </div>
  </header>
  <main>
${main}
  </main>
  <footer class="site-footer">
    <div class="container">© <span id="year">2026</span> ${name}. Built with AppForge AI.</div>
  </footer>
  <script src="script.js"></script>
</body>
</html>
`
}

function itemCard(kind: Kind, item: Item): string {
  const meta = item.meta ? `\n          <div class="meta">${escapeHtml(item.meta)}</div>` : ''
  const action = kind.shop
    ? '\n          <button class="btn small js-cart" type="button">Add to cart</button>'
    : kind.id === 'restaurant' || kind.id === 'fitness'
      ? '\n          <a class="btn small" href="contact.html">' + (kind.id === 'restaurant' ? 'Reserve' : 'Join') + '</a>'
      : ''
  return `        <article class="card">
          <div class="icon">${item.icon}</div>
          <h3>${escapeHtml(item.title)}</h3>
          <p>${escapeHtml(item.text)}</p>${meta}${action}
        </article>`
}

function homeMain(spec: Spec): string {
  const k = spec.kind
  const preview = k.items.slice(0, 3).map((i) => itemCard(k, i)).join('\n')
  const stats = k.stats.map(([big, small]) => `<div><b>${escapeHtml(big)}</b>${escapeHtml(small)}</div>`).join('')
  return `    <section class="hero">
      <div class="container">
        <h1>${escapeHtml(k.heroTitle(spec.name))}</h1>
        <p>${escapeHtml(k.heroText)}</p>
        <a class="btn" href="contact.html">${escapeHtml(k.cta)}</a>
        <div class="stats">${stats}</div>
      </div>
    </section>
    <section class="section">
      <div class="container">
        <h2>${escapeHtml(k.listLabel)}</h2>
        <p class="lead">${escapeHtml(k.listIntro)}</p>
        <div class="grid">
${preview}
        </div>
        <p><a href="${k.listFile}">See all ${escapeHtml(k.listLabel.toLowerCase())} →</a></p>
      </div>
    </section>
    <section class="section">
      <div class="container cta">
        <h2>Ready to get started?</h2>
        <p>Tell us what you need and we will get back to you quickly.</p>
        <a class="btn" href="contact.html">${escapeHtml(k.cta)}</a>
      </div>
    </section>`
}

function listMain(spec: Spec): string {
  const k = spec.kind
  return `    <section class="section">
      <div class="container">
        <h1>${escapeHtml(k.listLabel)}</h1>
        <p class="lead">${escapeHtml(k.listIntro)}</p>
        <div class="grid">
${k.items.map((i) => itemCard(k, i)).join('\n')}
        </div>
      </div>
    </section>`
}

function aboutMain(spec: Spec): string {
  const k = spec.kind
  const stats = k.stats.map(([big, small]) => `<div><b>${escapeHtml(big)}</b>${escapeHtml(small)}</div>`).join('')
  return `    <section class="section">
      <div class="container">
        <h1>About ${escapeHtml(spec.name)}</h1>
${k.about.map((p) => `        <p class="lead">${escapeHtml(p)}</p>`).join('\n')}
        <div class="stats">${stats}</div>
      </div>
    </section>`
}

function contactMain(): string {
  return `    <section class="section">
      <div class="container">
        <h1>Contact us</h1>
        <p class="lead">Send a message and we will reply within one working day. Email: hello@example.com · Phone: +91 98765 43210</p>
        <form id="contact-form" novalidate>
          <label>Name <input name="name" autocomplete="name"><span class="error" id="name-error"></span></label>
          <label>Email <input name="email" type="email" autocomplete="email"><span class="error" id="email-error"></span></label>
          <label>Message <textarea name="message" rows="5"></textarea><span class="error" id="message-error"></span></label>
          <button class="btn" type="submit">Send message</button>
          <div class="success" id="form-success" hidden>Thanks! Your message was received (demo form: nothing is sent).</div>
        </form>
      </div>
    </section>`
}

// ---------- public API ----------

export interface EngineResult {
  site: Site
  summary: string
}

/** Builds a complete multi-page website from a plain-English description. */
export function generateDemoSite(prompt: string): EngineResult {
  const kind = detectKind(prompt)
  const name = extractName(prompt, kind.defaultName)
  const dark = /\bdark (mode|theme|style)\b/i.test(prompt)
  const [accent, accentDark] = findColor(prompt) ?? COLORS[kind.accent]

  const spec: Spec = {
    name,
    kind,
    dark,
    pages: [
      ['index.html', 'Home'],
      [kind.listFile, kind.listLabel],
      ['about.html', 'About'],
      ['contact.html', 'Contact'],
    ],
  }

  const css = STYLES_CSS.replace('--accent: #2563eb;', `--accent: ${accent};`).replace(
    '--accent-dark: #1d4ed8;',
    `--accent-dark: ${accentDark};`,
  )

  const files: SiteFile[] = [
    { path: 'index.html', content: pageShell(spec, 'index.html', 'Home', homeMain(spec)) },
    { path: kind.listFile, content: pageShell(spec, kind.listFile, kind.listLabel, listMain(spec)) },
    { path: 'about.html', content: pageShell(spec, 'about.html', 'About', aboutMain(spec)) },
    { path: 'contact.html', content: pageShell(spec, 'contact.html', 'Contact', contactMain()) },
    { path: 'styles.css', content: css },
    { path: 'script.js', content: SCRIPT_JS },
  ]

  const description = `A ${kind.id} website for ${name} with ${spec.pages.length} pages.`
  return {
    site: { name, description, files },
    summary: `Created "${name}", a ${kind.id} website with ${spec.pages.length} pages (demo mode).`,
  }
}

// ---------- follow-up edits ----------

const SECTIONS: Record<string, { id: string; html: string }> = {
  testimonials: {
    id: 'testimonials',
    html: `    <section class="section" id="testimonials">
      <div class="container">
        <h2>What people say</h2>
        <p class="lead">Kind words from happy customers.</p>
        <div class="grid">
          <blockquote class="card">“Fast, friendly and exactly what we needed.”<p>- Priya S.</p></blockquote>
          <blockquote class="card">“Great quality and a really smooth experience.”<p>- Rahul M.</p></blockquote>
          <blockquote class="card">“I recommend them to all my friends.”<p>- Ayesha K.</p></blockquote>
        </div>
      </div>
    </section>`,
  },
  faq: {
    id: 'faq',
    html: `    <section class="section" id="faq">
      <div class="container">
        <h2>Frequently asked questions</h2>
        <div class="grid">
          <details class="card"><summary>How do I get started?</summary><p>Use the contact page and we will reply within one working day.</p></details>
          <details class="card"><summary>How much does it cost?</summary><p>Prices are listed on this site. Contact us for custom requests.</p></details>
          <details class="card"><summary>Can I cancel anytime?</summary><p>Yes. There are no hidden fees or long contracts.</p></details>
        </div>
      </div>
    </section>`,
  },
  pricing: {
    id: 'pricing',
    html: `    <section class="section" id="pricing">
      <div class="container">
        <h2>Simple pricing</h2>
        <p class="lead">Pick a plan that fits. Change or cancel anytime.</p>
        <div class="grid">
          <article class="card"><h3>Basic</h3><div class="meta">₹499/mo</div><p>Everything you need to get started.</p><a class="btn small" href="contact.html">Choose Basic</a></article>
          <article class="card"><h3>Standard</h3><div class="meta">₹999/mo</div><p>More features for growing needs.</p><a class="btn small" href="contact.html">Choose Standard</a></article>
          <article class="card"><h3>Pro</h3><div class="meta">₹1,999/mo</div><p>Priority support and everything included.</p><a class="btn small" href="contact.html">Choose Pro</a></article>
        </div>
      </div>
    </section>`,
  },
  newsletter: {
    id: 'newsletter',
    html: `    <section class="section" id="newsletter">
      <div class="container">
        <h2>Stay in the loop</h2>
        <p class="lead">Get updates and offers in your inbox.</p>
        <form id="newsletter-form">
          <label>Email <input name="newsletter-email" type="email" required></label>
          <button class="btn" type="submit">Subscribe</button>
          <div class="success" id="newsletter-success" hidden>Subscribed! (demo form: nothing is sent)</div>
        </form>
      </div>
    </section>`,
  },
}

function sectionKey(word: string): string | null {
  const w = word.toLowerCase()
  if (/^(testimonial|review)/.test(w)) return 'testimonials'
  if (/^(faq|question)/.test(w)) return 'faq'
  if (/^(pricing|plan|price)/.test(w)) return 'pricing'
  if (/^(newsletter|subscribe|signup|sign-up)/.test(w)) return 'newsletter'
  return null
}

export interface EditResult {
  site: Site
  summary: string
  changed: boolean
}

export const DEMO_EDIT_HELP =
  'Demo mode understands: "make it green" (or any colour / #hex), "dark mode", "rename the site to X", "change the headline to X", "add an FAQ page", and "add a testimonials / FAQ / pricing / newsletter section". Add an API key to the server for free-form AI edits.'

function mapHtml(files: SiteFile[], fn: (html: string, path: string) => string): SiteFile[] {
  return files.map((f) => (f.path.toLowerCase().endsWith('.html') ? { ...f, content: fn(f.content, f.path) } : f))
}

/** Applies a plain-English change to a site using simple rules. */
export function applyDemoEdit(site: Site, instruction: string): EditResult {
  let files = site.files.map((f) => ({ ...f }))
  let name = site.name
  let description = site.description
  const done: string[] = []
  let rest = ` ${instruction.trim()} `

  const take = (re: RegExp): RegExpExecArray | null => {
    const m = re.exec(rest)
    if (m) rest = rest.replace(m[0], ' ')
    return m
  }

  // 1) Add a page: "add an FAQ page"
  const pageMatch = take(/\badd\s+(?:an?\s+|the\s+)?([a-z0-9][a-z0-9 &-]{0,30}?)\s+page\b/i)
  if (pageMatch) {
    const label = titleCase(pageMatch[1].trim())
    const file = `${slugify(label)}.html`
    const index = files.find((f) => f.path === 'index.html')
    const mainRe = /(<main\b[^>]*>)[\s\S]*(<\/main>)/i
    if (files.some((f) => f.path === file)) {
      done.push(`The ${label} page already exists`)
    } else if (!index || !mainRe.test(index.content) || !/class="nav-links"/.test(index.content)) {
      done.push(`Could not add a page (demo mode only edits sites it created)`)
    } else {
      const key = sectionKey(label)
      const body = key
        ? SECTIONS[key].html
        : `    <section class="section">
      <div class="container">
        <h1>${escapeHtml(label)}</h1>
        <p class="lead">This is your new ${escapeHtml(label)} page. Tell me what to put here.</p>
      </div>
    </section>`
      // First add the menu link to every existing page...
      files = mapHtml(files, (html) =>
        html.replace(/(<ul class="nav-links"[^>]*>[\s\S]*?)(\s*<\/ul>)/i, (_m, head: string, tail: string) =>
          `${head}\n        <li><a href="${file}">${escapeHtml(label)}</a></li>${tail}`),
      )
      // ...then clone the (updated) home page as the starting point of the new page.
      const updatedIndex = files.find((f) => f.path === 'index.html')!
      const newPage = updatedIndex.content
        .replace(/ aria-current="page"/g, '')
        .replace(`<a href="${file}">`, `<a href="${file}" aria-current="page">`)
        .replace(mainRe, (_m, open: string, close: string) => `${open}\n${body}\n  ${close}`)
        .replace(/<title>[\s\S]*?<\/title>/i, `<title>${escapeHtml(label)} - ${escapeHtml(name)}</title>`)
      files.push({ path: file, content: newPage })
      done.push(`Added a ${label} page and linked it in the menu`)
    }
  }

  // 2) Add a section: "add a testimonials section"
  const sectionMatch = take(
    /\b(?:add|include|insert|put)\s+(?:an?\s+|the\s+|some\s+)?(testimonials?|reviews?|faq|pricing|plans?|newsletter|subscribe)(?:\s+(?:section|form|block))?\b/i,
  )
  if (sectionMatch) {
    const key = sectionKey(sectionMatch[1])
    const section = key ? SECTIONS[key] : null
    const index = files.find((f) => f.path === 'index.html')
    if (!section || !index) {
      done.push('Could not add that section')
    } else if (index.content.includes(`id="${section.id}"`)) {
      done.push(`The ${section.id} section is already on the home page`)
    } else if (!/<\/main>/i.test(index.content)) {
      done.push('Could not add a section (demo mode only edits sites it created)')
    } else {
      index.content = index.content.replace(/<\/main>/i, () => `${section.html}\n  </main>`)
      done.push(`Added a ${section.id} section to the home page`)
    }
  }

  // 3) Change the headline
  const headline = take(
    /\b(?:headline|hero(?: title| text)?|main (?:heading|title)|heading)\s+(?:to|as|:)\s+["“']?(.+?)["”']?\s*(?=$|[.;!]| and )/i,
  )
  if (headline) {
    const text = headline[1].trim()
    const index = files.find((f) => f.path === 'index.html')
    if (index && /<h1\b[^>]*>[\s\S]*?<\/h1>/i.test(index.content)) {
      index.content = index.content.replace(/(<h1\b[^>]*>)[\s\S]*?(<\/h1>)/i, (_m, a: string, b: string) => `${a}${escapeHtml(text)}${b}`)
      done.push(`Changed the headline to "${text}"`)
    } else {
      done.push('Could not find a headline to change')
    }
  }

  // 4) Rename the site
  const rename =
    take(
      /\b(?:rename|change)\s+(?:the\s+)?(?:site|website|brand|business|app|project)?\s*(?:name|title)?\s*(?:it\s+)?to\s+["“']?(.+?)["”']?\s*(?=$|[.,;!]| and )/i,
    ) ?? take(/\b(?:call|name)\s+it\s+["“']?(.+?)["”']?\s*(?=$|[.,;!]| and )/i)
  if (rename) {
    const next = rename[1].trim().slice(0, 60)
    if (next && next !== name) {
      const from = escapeHtml(name)
      const to = escapeHtml(next)
      files = mapHtml(files, (html) => html.split(from).join(to))
      description = description.split(name).join(next)
      done.push(`Renamed the site from "${name}" to "${next}"`)
      name = next
    }
  }

  // 5) Dark / light mode
  const wantsLight = /\blight (mode|theme)\b/i.test(rest)
  const wantsDark = !wantsLight && /\bdark(er)?( mode| theme| style| background)?\b/i.test(rest)
  if (wantsDark) {
    rest = rest.replace(/\bdark(er)?( mode| theme| style| background)?\b/i, ' ')
    files = mapHtml(files, (html) =>
      html.replace(/<html\b([^>]*)>/i, (m, attrs: string) =>
        /data-theme=/.test(attrs) ? m.replace(/data-theme="[^"]*"/, 'data-theme="dark"') : `<html${attrs} data-theme="dark">`,
      ),
    )
    done.push('Switched to dark mode')
  } else if (wantsLight) {
    files = mapHtml(files, (html) => html.replace(/ data-theme="[^"]*"/, ''))
    done.push('Switched to light mode')
  }

  // 6) Accent colour
  const color = findColor(rest)
  if (color && /\b(colou?r|theme|accent|buttons?|brand|make|change|switch|use|turn|paint)\b/i.test(rest)) {
    const css = files.find((f) => f.path === 'styles.css')
    if (css && /--accent:\s*#[0-9a-f]{3,8};/i.test(css.content)) {
      css.content = css.content
        .replace(/--accent:\s*#[0-9a-f]{3,8};/i, `--accent: ${color[0]};`)
        .replace(/--accent-dark:\s*#[0-9a-f]{3,8};/i, `--accent-dark: ${color[1]};`)
      done.push(`Changed the main colour to ${color[0]}`)
    } else {
      done.push('Could not find the colour settings in styles.css')
    }
  }

  if (done.length === 0) {
    return { site, summary: `I did not understand that edit in demo mode. ${DEMO_EDIT_HELP}`, changed: false }
  }
  return {
    site: { name, description, files },
    summary: `${done.join('. ')}. (demo mode)`,
    changed: true,
  }
}
