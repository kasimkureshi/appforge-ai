import type { Site, SiteFile } from './types'

/**
 * A tiny ZIP writer with no dependencies (files are stored, not compressed,
 * which is fine for small websites). It runs in the browser and in Node.
 */

const encoder = new TextEncoder()

const CRC_TABLE = (() => {
  const table = new Uint32Array(256)
  for (let n = 0; n < 256; n++) {
    let c = n
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1
    table[n] = c >>> 0
  }
  return table
})()

export function crc32(data: Uint8Array): number {
  let c = 0xffffffff
  for (let i = 0; i < data.length; i++) c = CRC_TABLE[(c ^ data[i]) & 0xff] ^ (c >>> 8)
  return (c ^ 0xffffffff) >>> 0
}

function dosDateTime(d: Date): { time: number; date: number } {
  const time = (d.getHours() << 11) | (d.getMinutes() << 5) | Math.floor(d.getSeconds() / 2)
  const date = ((Math.max(d.getFullYear(), 1980) - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate()
  return { time, date }
}

export function createZip(files: SiteFile[], now: Date = new Date()): Uint8Array {
  const parts: Uint8Array[] = []
  const central: Uint8Array[] = []
  const { time, date } = dosDateTime(now)
  let offset = 0

  for (const file of files) {
    const name = encoder.encode(file.path)
    const data = encoder.encode(file.content)
    const crc = crc32(data)

    const local = new Uint8Array(30 + name.length)
    const lv = new DataView(local.buffer)
    lv.setUint32(0, 0x04034b50, true) // local file header signature
    lv.setUint16(4, 20, true) // version needed
    lv.setUint16(6, 0x0800, true) // UTF-8 file names
    lv.setUint16(8, 0, true) // method 0 = stored
    lv.setUint16(10, time, true)
    lv.setUint16(12, date, true)
    lv.setUint32(14, crc, true)
    lv.setUint32(18, data.length, true)
    lv.setUint32(22, data.length, true)
    lv.setUint16(26, name.length, true)
    lv.setUint16(28, 0, true)
    local.set(name, 30)

    const entry = new Uint8Array(46 + name.length)
    const cv = new DataView(entry.buffer)
    cv.setUint32(0, 0x02014b50, true) // central directory signature
    cv.setUint16(4, 20, true)
    cv.setUint16(6, 20, true)
    cv.setUint16(8, 0x0800, true)
    cv.setUint16(10, 0, true)
    cv.setUint16(12, time, true)
    cv.setUint16(14, date, true)
    cv.setUint32(16, crc, true)
    cv.setUint32(20, data.length, true)
    cv.setUint32(24, data.length, true)
    cv.setUint16(28, name.length, true)
    cv.setUint32(42, offset, true)
    entry.set(name, 46)

    parts.push(local, data)
    central.push(entry)
    offset += local.length + data.length
  }

  const centralSize = central.reduce((sum, c) => sum + c.length, 0)
  const end = new Uint8Array(22)
  const ev = new DataView(end.buffer)
  ev.setUint32(0, 0x06054b50, true) // end of central directory
  ev.setUint16(8, files.length, true)
  ev.setUint16(10, files.length, true)
  ev.setUint32(12, centralSize, true)
  ev.setUint32(16, offset, true)

  const all = [...parts, ...central, end]
  const out = new Uint8Array(all.reduce((sum, p) => sum + p.length, 0))
  let pos = 0
  for (const p of all) {
    out.set(p, pos)
    pos += p.length
  }
  return out
}

function readme(site: Site): string {
  const pages = site.files.filter((f) => f.path.endsWith('.html')).map((f) => `- ${f.path}`)
  return `# ${site.name}

${site.description}

Generated with AppForge AI.

## How to open it
1. Unzip this folder.
2. Open \`index.html\` in any browser. No build step or server is needed.

## Pages
${pages.join('\n')}

## How to put it online
Upload the whole folder to any static host (Netlify Drop, GitHub Pages, Cloudflare Pages, Vercel).
`
}

/** Builds the downloadable ZIP for a site (adds a README.md if the site has none). */
export function buildSiteZip(site: Site): Uint8Array {
  const files = site.files.some((f) => f.path.toLowerCase() === 'readme.md')
    ? site.files
    : [...site.files, { path: 'README.md', content: readme(site) }]
  return createZip(files)
}

/** A safe file name for the download, like "bright-bakes.zip". */
export function zipFileName(site: Site): string {
  const slug = site.name
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
  return `${slug || 'website'}.zip`
}
