/** One file inside a generated website (for example "index.html"). */
export interface SiteFile {
  path: string
  content: string
}

/** A complete generated website: a name plus its source files. */
export interface Site {
  name: string
  description: string
  files: SiteFile[]
}

/** "demo" = built-in generator (no API key). "ai" = real AI model on the server. */
export type EngineMode = 'demo' | 'ai'

export interface GenerateRequest {
  prompt: string
  forceDemo?: boolean
}

export interface EditRequest {
  site: Site
  instruction: string
  forceDemo?: boolean
}

export interface SiteResponse {
  site: Site
  mode: EngineMode
  summary: string
}

export interface StatusResponse {
  mode: EngineMode
  aiConfigured: boolean
  model?: string
}

export interface ErrorResponse {
  error: string
}

/** Safety limits. They protect the server (and your AI bill) from huge requests. */
export const LIMITS = {
  minPromptChars: 3,
  maxPromptChars: 2000,
  maxInstructionChars: 1000,
  maxFiles: 30,
  maxFileBytes: 200_000,
  maxTotalBytes: 800_000,
} as const
